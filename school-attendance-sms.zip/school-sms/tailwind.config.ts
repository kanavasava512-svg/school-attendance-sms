import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      fontFamily: {
        gujarati: ['var(--font-gujarati)', 'sans-serif'],
      },
      colors: {
        brand: {
          50: '#eef4ff',
          100: '#d9e6ff',
          500: '#2f5fd6',
          600: '#254bab',
          700: '#1c3a85',
        },
      },
    },
  },
  plugins: [],
};
export default config;
