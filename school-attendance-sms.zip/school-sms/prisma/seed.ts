// Seeds only the School configuration row (name, logo placeholder, default SMS
// template). Deliberately does NOT create any demo students — per the project
// spec, real student data only ever enters the system through Excel upload.

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const existing = await prisma.school.findFirst();
  if (existing) {
    console.log('School row already exists — skipping seed.');
    return;
  }

  await prisma.school.create({
    data: {
      nameGujarati: 'શ્રી નાના દિનારા-1 પ્રાથમિક શાળા',
      nameEnglish: 'Shri Nana Dinara-1 Primary School',
      taluka: 'ભુજ',
      district: 'કચ્છ',
      email: 'nanadinara1@gmail.com',
      mobile: '9913981008',
      schoolCode: '24010500702',
      smsTemplate:
        'પ્રિય વાલી શ્રી, આપનું બાળક {student_name_gujarati} આજે {date}ના રોજ શાળામાં ગેરહાજર છે. કૃપા કરીને કારણ શાળાને જણાવશો. {school_name}.',
    },
  });

  console.log('School settings seeded.');
  console.log('Next: log in as Principal with PRINCIPAL_MOBILE_NUMBER, then upload your real student Excel.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
