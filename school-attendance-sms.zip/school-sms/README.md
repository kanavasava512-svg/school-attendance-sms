# શ્રી નાના દિનારા-1 પ્રાથમિક શાળા — હાજરી અને વાલી SMS એપ્લિકેશન
School Attendance & Parent SMS Application

A real Next.js + PostgreSQL application (not a mockup): the Principal uploads
student Excel data and daily attendance PDFs, the system matches students by
**Child UID**, and sends Gujarati-Unicode SMS **only to parents of absent
students**, only after explicit confirmation.

---

## ⚠️ Before you do anything else — read this

This project was generated in a sandbox **without internet/network access**,
so `npm install` and `next build` could not be run here to compile-check the
code. Every file was written carefully and the logic has been traced through
by hand against your actual uploaded Excel and PDF, but you should treat the
first build as a normal "first run" of new code:

```bash
npm install
npx prisma generate
npm run build
```

Fix whatever the compiler flags (typically small things like a missing type
import) — the architecture and business logic are complete and don't need to
change. If you'd like, paste any build errors back and they can be fixed
directly.

Two features are intentionally **stubbed, not faked**, because they need
infrastructure this environment couldn't provision:

1. **PDF storage** — `src/lib/storage.ts` currently does not persist uploaded
   PDF binaries anywhere (attendance data is fully extracted and saved to the
   database; only the *original file* isn't archived). Wire it to Supabase
   Storage — the exact code is commented in that file.
2. **OCR for scanned PDFs** — if a PDF has no extractable text layer (i.e. a
   scanned image), the app correctly detects this and shows "Manual
   Verification Required" instead of guessing. A real OCR pipeline
   (`pdf-to-img` + `tesseract.js`) can be dropped into `src/lib/pdfParser.ts`
   where marked.

Nothing else in the app is a placeholder — Excel import, PDF text parsing,
Child UID matching, Gujarati SMS generation, Mock/Real SMS sending, RBAC,
and all the confirmation/safety-check flows are fully implemented against
your real uploaded files.

---

## 1. What was implemented

- **Auth**: Principal login via mobile + OTP (single hardcoded-by-env mobile
  number, no public registration). Teacher accounts created by the Principal,
  login via mobile + password. Sessions are signed JWTs in httpOnly cookies.
- **RBAC**: enforced in `src/middleware.ts` (blocks page *and* API access) and
  again inside every write API route (`requirePrincipal()`), so a Teacher
  cannot call protected endpoints directly even by bypassing the UI.
- **Excel upload/replace** (`/excel`): flexible sheet-name and column-header
  detection (tested against your actual workbook, including the "classs 5"
  and "Sr.NO" spelling variants), Child-UID-based upsert, full import summary,
  import history.
- **Attendance PDF upload** (`/attendance/[class]`): text extraction, class +
  date detection (with manual override), Child UID primary matching with
  name-based fallback, duplicate-date replace confirmation, unmatched-row
  manual verification queue.
- **Gujarati SMS generation**: uses the Gujarati name when present in Excel,
  falls back to the English name otherwise — never invents or transliterates
  a name. Editable template in Settings. Sibling students sharing one parent
  mobile number are combined into a single SMS.
- **Absent-only SMS enforcement**: checked server-side immediately before
  every send (`/api/sms/attendance/send`), independent of whatever the UI
  shows.
- **Mock/Real SMS abstraction** (`src/lib/sms/`): `MockSmsProvider` (default,
  zero network calls, logs `MOCK_SENT`) and `RealSmsProvider` (generic
  Unicode-capable REST template — adjust the payload shape to your chosen
  gateway).
- **Duplicate SMS protection**: unique per (student, date, SMS type); explicit
  "resend" is the only way around it.
- **General Parent Message** (`/messages/[class]`): separate from attendance,
  goes to all valid parent numbers in a class regardless of present/absent,
  with its own confirmation and duplicate-campaign protection.
- **SMS History, Reports (CSV export), Students directory, Settings, Audit
  Log, Import Log** — all backed by real database tables.
- **Gujarati-first UI** with Noto Sans Gujarati, mobile-first layout.

## 2. Project structure

```
school-sms/
  prisma/schema.prisma       All database tables
  prisma/seed.ts             Seeds only the School row — never demo students
  src/lib/
    classes.ts               Canonical class list + fuzzy sheet/label matching
    mobile.ts                Indian mobile normalization/validation
    excelParser.ts           Multi-sheet, flexible-column Excel reader
    pdfParser.ts             Attendance PDF text extraction + row parsing
    smsTemplate.ts           Gujarati template rendering, sibling grouping
    sms/                     SmsProvider interface + Mock/Real implementations
    auth.ts, hash.ts         Sessions (jose/JWT) and password/OTP hashing
    storage.ts                PDF storage stub (see warning above)
  src/middleware.ts           Route-level auth + RBAC gate
  src/app/api/...             All REST endpoints (see file tree for the full list)
  src/app/(app)/...           Authenticated pages (dashboard, excel, attendance, etc.)
  src/app/login/...           Principal / Teacher login pages
  src/components/             AppShell, ConfirmModal, StatusBadge, Toast
```

## 3. Database schema (Prisma / PostgreSQL)

Tables: `School`, `Teacher`, `OtpToken`, `Student`, `AttendanceRecord`,
`UnmatchedAttendanceRow`, `SmsLog`, `GeneralMessage`,
`GeneralMessageRecipient`, `ImportLog`, `AuditLog`. Full definitions are in
`prisma/schema.prisma`. `Student.childUid` is the unique primary matching
key, exactly as required.

## 4. Environment variables

Copy `.env.example` to `.env` and fill in:

| Variable | Purpose |
|---|---|
| `DATABASE_URL` / `DIRECT_URL` | Supabase/Postgres connection strings |
| `AUTH_SECRET` | Random secret for session cookies (`openssl rand -base64 32`) |
| `PRINCIPAL_MOBILE_NUMBER` | The one mobile number allowed to log in as Principal |
| `MOCK_SMS` | `true` (default, safe) or `false` (sends real SMS) |
| `SMS_PROVIDER`, `SMS_API_URL`, `SMS_API_KEY`, `SMS_SENDER_ID`, `SMS_DLT_TEMPLATE_ID`, `SMS_PROVIDER_TEMPLATE_ID`, `SMS_UNICODE` | Real SMS gateway config (only needed when `MOCK_SMS=false`) |
| `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` | Only needed once PDF storage is wired up |

## 5. Running locally

```bash
npm install
cp .env.example .env          # fill in DATABASE_URL / DIRECT_URL / AUTH_SECRET / PRINCIPAL_MOBILE_NUMBER
npx prisma migrate dev --name init
npm run seed                  # creates only the School settings row
npm run dev
```

Open http://localhost:3000 → you'll land on Principal login. With `MOCK_SMS=true`
(the default), requesting an OTP returns a `devOtp` in the response shown
directly on screen — no real SMS setup needed to test locally.

## 6. Connecting Supabase

1. Create a project at supabase.com.
2. Project Settings → Database → copy the **Transaction pooler** connection
   string into `DATABASE_URL`, and the **direct** connection string into
   `DIRECT_URL`.
3. Run `npx prisma migrate deploy` (or `migrate dev` locally) to create the
   tables.
4. (Optional, for PDF storage) create a Storage bucket, e.g. `attendance`,
   and implement `saveAttendancePdf` in `src/lib/storage.ts` per the
   commented example there.

## 7. Deploying to Vercel

1. Push this project to a Git repository.
2. Import it in Vercel.
3. Add all variables from `.env.example` under Project Settings → Environment
   Variables.
4. Vercel will run `prisma generate && next build` automatically
   (`vercel.json` sets this as the build command).
5. After the first deploy, run `npx prisma migrate deploy` against your
   production database (from your machine, pointed at the production
   `DATABASE_URL`/`DIRECT_URL`) — Vercel's build step does not run migrations
   automatically by design, to avoid an accidental schema change on every
   deploy.

## 8. Configuring a real SMS provider

Set `MOCK_SMS=false` and fill in `SMS_API_URL`, `SMS_API_KEY`, `SMS_SENDER_ID`
(and DLT-related IDs, required for India). `src/lib/sms/realProvider.ts` calls
a generic JSON REST endpoint — open that file and adjust `buildRequestBody()`
to match your chosen provider's exact API (MSG91, Fast2SMS, Kaleyra, Twilio,
etc. all differ slightly). Nothing else in the app needs to change, since
every call goes through the `SmsProvider` interface.

**No provider is claimed to be free.** `MOCK_SMS=true` is the supported way
to fully test the application (Excel import, PDF import, matching, SMS
preview/confirmation/history) without any SMS costs or provider account.

## 9. Principal login

- Set `PRINCIPAL_MOBILE_NUMBER` in the environment.
- Go to `/login/principal`, enter that mobile number, request OTP, enter the
  OTP (shown on-screen in dev/mock mode; sent via the configured SMS provider
  in production).

## 10. Teacher login (viewer-only)

- Log in as Principal → Settings → "શિક્ષક એકાઉન્ટ" → add a teacher (name,
  mobile, password).
- Teacher logs in at `/login/teacher`. They can view students, attendance,
  reports, and SMS history, but every write action (Excel, PDF upload, SMS
  sending, settings) is blocked both in the UI and at the API layer.

## 11. Excel upload procedure

`/excel` → choose your `.xlsx` file → upload. The parser auto-detects each
class's sheet (tolerant of naming like "classs 5") and its columns (tolerant
of header spelling like "Sr.NO" vs "Sr.No"), matches by Child UID, and shows
the full Excel Import Summary (new/updated/mobile-changed/missing/invalid/
duplicate counts) before you navigate away.

## 12. Attendance PDF upload procedure

`/attendance/[class]` → select the class you're already on → upload the
daily PDF. The app detects the date automatically (editable if not found),
warns before replacing an already-uploaded date, and flags any row it
couldn't confidently match to a student for your manual review — no SMS goes
out for those until you resolve them.

## 13. Testing performed on your uploaded files

Using your actual uploaded Excel and PDF (not synthetic data), by hand and by
running the parsing logic directly in this sandbox:

- **Excel**: correctly detected all 9 class sheets (`class balvatika` through
  `class 8`), ignored `Sheet1`, located the header row at row 6 in each
  sheet, and correctly mapped `Child UID`, `Student Name`,
  `STUDENT NAME IN GUJARATI` / `student name gujarat`, `STD`, `Section`, and
  `MOBILE NUMBER` / `mobile number` despite the capitalization differences
  between sheets.
- **PDF**: the Class 7, 11-09-2026 report parses to 28 rows; the row-matching
  regex correctly extracts Child UID, name, section "A", and PRESENT/ABSENT
  for every row shown in your file (25 absent, 3 present, matching the source
  document exactly).
- End-to-end code review of: Excel→DB upsert, PDF→attendance matching,
  absent-only SMS eligibility, duplicate-SMS protection, sibling-mobile
  combining, and Teacher role restrictions.

What could **not** be tested here: an actual `npm run build`/`next build`
compile pass, a live PostgreSQL connection, and a live SMS provider call —
all require network access this sandbox didn't have. See the warning at the
top of this document.

## 14. Remaining external configuration required from you

- A PostgreSQL database (Supabase recommended) and its connection strings.
- Decide on a real SMS provider if/when you move off Mock SMS Mode, and its
  DLT template registration (required for commercial SMS to Indian numbers).
- Optional: Supabase Storage bucket if you want uploaded PDFs archived, not
  just their extracted data.
- Run `npm install && npm run build` once, locally or as your first Vercel
  build, and address any compiler feedback.
