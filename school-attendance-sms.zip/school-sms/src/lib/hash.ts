import { scryptSync, randomBytes, timingSafeEqual } from 'crypto';

// Uses Node's built-in crypto (scrypt) instead of bcrypt/argon2 so there is no
// native addon to compile — keeps the project trivially deployable on Vercel.

export function hashSecret(secret: string): string {
  const salt = randomBytes(16);
  const derived = scryptSync(secret, salt, 64);
  return `${salt.toString('hex')}:${derived.toString('hex')}`;
}

export function verifySecret(secret: string, stored: string): boolean {
  const [saltHex, hashHex] = stored.split(':');
  if (!saltHex || !hashHex) return false;
  const salt = Buffer.from(saltHex, 'hex');
  const hash = Buffer.from(hashHex, 'hex');
  const derived = scryptSync(secret, salt, 64);
  if (derived.length !== hash.length) return false;
  return timingSafeEqual(derived, hash);
}

export function generateOtp(): string {
  // 6-digit numeric OTP
  return String(Math.floor(100000 + Math.random() * 900000));
}
