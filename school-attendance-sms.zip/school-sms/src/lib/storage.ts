// Minimal storage abstraction for uploaded attendance PDFs.
//
// This build does not have a configured object-storage backend (no network
// access was available while generating this project to provision one), so
// `saveAttendancePdf` currently only returns a descriptive reference string
// and does NOT persist the binary anywhere. Wire this up to Supabase Storage
// (or S3/R2) before relying on historical PDF access — see README "Storage"
// section for the exact steps.

export async function saveAttendancePdf(fileName: string, _buffer: Buffer): Promise<string> {
  // Example of what a real implementation looks like with Supabase Storage:
  //
  // import { createClient } from '@supabase/supabase-js';
  // const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);
  // const path = `attendance-pdfs/${Date.now()}-${fileName}`;
  // await supabase.storage.from('attendance').upload(path, _buffer, { contentType: 'application/pdf' });
  // return path;

  return `unstored:${fileName}`;
}
