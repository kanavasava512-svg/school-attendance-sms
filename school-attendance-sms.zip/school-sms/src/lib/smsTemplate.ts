import { getClass } from './classes';

export type TemplateVars = {
  studentName: string;
  studentNameGujarati?: string | null;
  date: string; // already formatted dd-mm-yyyy
  classSlug: string;
  schoolNameGujarati: string;
};

// Renders the editable attendance SMS template. Uses the Gujarati name when
// available, otherwise falls back to the Excel student name as-is (never
// invented or auto-translated, per spec).
export function renderAttendanceSms(template: string, vars: TemplateVars): string {
  const nameForSms = vars.studentNameGujarati?.trim() || vars.studentName;
  const classDef = getClass(vars.classSlug);

  return template
    .replaceAll('{student_name_gujarati}', nameForSms)
    .replaceAll('{student_name}', nameForSms)
    .replaceAll('{બાળકનું નામ}', nameForSms)
    .replaceAll('{date}', vars.date)
    .replaceAll('{તારીખ}', vars.date)
    .replaceAll('{class}', classDef?.labelGujarati ?? vars.classSlug)
    .replaceAll('{school_name}', vars.schoolNameGujarati);
}

export function formatDateDMY(d: Date): string {
  const dd = String(d.getUTCDate()).padStart(2, '0');
  const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
  const yyyy = d.getUTCFullYear();
  return `${dd}-${mm}-${yyyy}`;
}

export function combineSiblingMessage(
  template: string,
  studentNames: string[],
  date: string,
  schoolNameGujarati: string
): string {
  // Combines multiple children sharing one parent mobile number into a single
  // SMS, per spec section 33, while keeping each child's name visible.
  const listing = studentNames.map((n, i) => `${i + 1}. ${n}`).join('\n');
  return `પ્રિય વાલી શ્રી, આપના બાળકો:\n${listing}\n\nઆજે ${date}ના રોજ શાળામાં ગેરહાજર છે. કૃપા કરીને કારણ શાળાને જણાવશો. ${schoolNameGujarati}.`;
}
