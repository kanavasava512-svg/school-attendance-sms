import { prisma } from './prisma';
import { SessionPayload } from './auth';

export async function logAudit(session: SessionPayload, action: string, details?: Record<string, unknown>) {
  try {
    await prisma.auditLog.create({
      data: {
        actorRole: session.role,
        actorId: session.sub,
        action,
        details: details ? (details as any) : undefined,
      },
    });
  } catch (err) {
    // Auditing must never break the primary action it's logging.
    // eslint-disable-next-line no-console
    console.error('Failed to write audit log', err);
  }
}
