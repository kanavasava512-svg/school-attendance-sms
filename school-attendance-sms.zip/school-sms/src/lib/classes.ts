// Canonical class definitions. `slug` is the stable key stored on Student.className.
// `sheetAliases` / `pdfAliases` are used for flexible detection of the source
// Excel sheet name or the class label printed in the attendance PDF — school data
// entry is inconsistent (e.g. "classs 5", "Class-7", "STD 7"), so detection is
// tolerant rather than exact-match.

export type ClassDef = {
  slug: string;
  order: number;
  labelGujarati: string;
  labelEnglish: string;
  // normalized forms (lowercase, no spaces/punctuation) that should map to this class
  aliases: string[];
};

function norm(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]/g, '');
}

type RawClass = { slug: string; order: number; labelGujarati: string; labelEnglish: string; aliasSeeds: string[] };

const RAW_CLASSES: RawClass[] = [
  { slug: 'balvatika', order: 0, labelGujarati: 'બાલવાટિકા', labelEnglish: 'Balvatika', aliasSeeds: ['balvatika', 'bal vatika', 'balwatika'] },
  { slug: 'class_1', order: 1, labelGujarati: 'ધોરણ 1', labelEnglish: 'Class 1', aliasSeeds: ['class1', 'class 1', 'std1', 'std 1', 'dhoran1'] },
  { slug: 'class_2', order: 2, labelGujarati: 'ધોરણ 2', labelEnglish: 'Class 2', aliasSeeds: ['class2', 'class 2', 'std2', 'std 2'] },
  { slug: 'class_3', order: 3, labelGujarati: 'ધોરણ 3', labelEnglish: 'Class 3', aliasSeeds: ['class3', 'class 3', 'std3', 'std 3'] },
  { slug: 'class_4', order: 4, labelGujarati: 'ધોરણ 4', labelEnglish: 'Class 4', aliasSeeds: ['class4', 'class 4', 'std4', 'std 4'] },
  { slug: 'class_5', order: 5, labelGujarati: 'ધોરણ 5', labelEnglish: 'Class 5', aliasSeeds: ['class5', 'classs5', 'class 5', 'std5', 'std 5'] },
  { slug: 'class_6', order: 6, labelGujarati: 'ધોરણ 6', labelEnglish: 'Class 6', aliasSeeds: ['class6', 'class 6', 'std6', 'std 6'] },
  { slug: 'class_7', order: 7, labelGujarati: 'ધોરણ 7', labelEnglish: 'Class 7', aliasSeeds: ['class7', 'class 7', 'std7', 'std 7'] },
  { slug: 'class_8', order: 8, labelGujarati: 'ધોરણ 8', labelEnglish: 'Class 8', aliasSeeds: ['class8', 'class 8', 'std8', 'std 8'] },
];

export const CLASSES: ClassDef[] = RAW_CLASSES.map((c) => ({
  slug: c.slug,
  order: c.order,
  labelGujarati: c.labelGujarati,
  labelEnglish: c.labelEnglish,
  aliases: c.aliasSeeds.map(norm),
}));

export function findClassBySheetName(sheetName: string): ClassDef | null {
  const n = norm(sheetName);
  if (!n) return null;
  for (const c of CLASSES) {
    if (c.aliases.includes(n)) return c;
  }
  // fallback: contains match (e.g. "ClassSeven_Section" style names)
  for (const c of CLASSES) {
    if (c.aliases.some((a) => n.includes(a))) return c;
  }
  return null;
}

// Detect a class from free text such as "Attendance Report for Class: 7" or "STD 7".
export function findClassFromText(text: string): ClassDef | null {
  const n = norm(text);
  // try to find a standalone number 0-8 associated with class/std keyword, or "balvatika"
  if (n.includes('balvatika') || n.includes('balwatika')) {
    return CLASSES.find((c) => c.slug === 'balvatika') ?? null;
  }
  const match = text.match(/(?:class|std|ધોરણ)\D{0,3}(\d{1,2})/i);
  if (match) {
    const num = parseInt(match[1], 10);
    return CLASSES.find((c) => c.slug === `class_${num}`) ?? null;
  }
  return null;
}

export function getClass(slug: string): ClassDef | undefined {
  return CLASSES.find((c) => c.slug === slug);
}

export function sheetIsIgnorable(sheetName: string): boolean {
  const n = norm(sheetName);
  return n === 'sheet1' || n === 'sheet2' || n === 'sheet3';
}
