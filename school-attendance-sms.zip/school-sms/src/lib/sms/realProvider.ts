import { SmsProvider, SendSmsResult } from './types';

// Generic template for a real, production Unicode SMS gateway (e.g. MSG91,
// Fast2SMS, Twilio, Kaleyra). Every Indian SMS provider has a slightly different
// request shape and DLT/template requirements, so this class calls a
// provider-agnostic REST endpoint configured entirely through environment
// variables. Adjust `buildRequest` for your chosen provider's exact API —
// nothing else in the app needs to change, since it only talks to the
// SmsProvider interface.
export class RealSmsProvider implements SmsProvider {
  private apiUrl: string;
  private apiKey: string;
  private senderId: string;
  private unicode: boolean;
  private dltTemplateId?: string;
  private providerTemplateId?: string;

  constructor() {
    this.apiUrl = process.env.SMS_API_URL || '';
    this.apiKey = process.env.SMS_API_KEY || '';
    this.senderId = process.env.SMS_SENDER_ID || '';
    this.unicode = (process.env.SMS_UNICODE || 'true').toLowerCase() === 'true';
    this.dltTemplateId = process.env.SMS_DLT_TEMPLATE_ID;
    this.providerTemplateId = process.env.SMS_PROVIDER_TEMPLATE_ID;
  }

  validateConfiguration(): { ok: boolean; error?: string } {
    if (!this.apiUrl || !this.apiKey || !this.senderId) {
      return {
        ok: false,
        error:
          'SMS_API_URL, SMS_API_KEY and SMS_SENDER_ID must be set to send real SMS. Set MOCK_SMS=true to keep using Mock SMS Mode.',
      };
    }
    if (!this.unicode) {
      return {
        ok: false,
        error: 'આ SMS Provider ગુજરાતી Unicode SMS support કરતું નથી.',
      };
    }
    return { ok: true };
  }

  checkUnicodeSupport(): boolean {
    return this.unicode;
  }

  private buildRequestBody(to: string, message: string) {
    // Adjust this payload shape to match your chosen provider's API contract.
    return {
      sender_id: this.senderId,
      to,
      message,
      unicode: this.unicode ? 1 : 0,
      dlt_template_id: this.dltTemplateId,
      provider_template_id: this.providerTemplateId,
    };
  }

  async sendSms(to: string, message: string): Promise<SendSmsResult> {
    const config = this.validateConfiguration();
    if (!config.ok) return { success: false, error: config.error };

    try {
      const res = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify(this.buildRequestBody(to, message)),
      });

      if (!res.ok) {
        const text = await res.text().catch(() => '');
        return { success: false, error: `Provider error (${res.status}): ${text.slice(0, 300)}` };
      }

      const data = (await res.json().catch(() => ({}))) as { message_id?: string; id?: string };
      return { success: true, providerMessageId: data.message_id || data.id };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err.message : 'Unknown SMS provider error' };
    }
  }

  async sendBulkSms(messages: { to: string; message: string }[]): Promise<SendSmsResult[]> {
    const results: SendSmsResult[] = [];
    for (const m of messages) {
      results.push(await this.sendSms(m.to, m.message));
    }
    return results;
  }
}
