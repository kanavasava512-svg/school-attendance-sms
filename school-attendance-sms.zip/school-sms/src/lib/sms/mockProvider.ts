import { SmsProvider, SendSmsResult } from './types';

// Simulates SMS sending for development/testing. Guaranteed to never make a
// network call, so it is safe to run with real-looking data at any time.
export class MockSmsProvider implements SmsProvider {
  async sendSms(to: string, message: string): Promise<SendSmsResult> {
    // Simulate small latency so the UI's "sending..." progress state is visible.
    await new Promise((res) => setTimeout(res, 60));
    // eslint-disable-next-line no-console
    console.log(`[MOCK SMS] to=${to} message="${message}"`);
    return {
      success: true,
      mock: true,
      providerMessageId: `MOCK-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
    };
  }

  async sendBulkSms(messages: { to: string; message: string }[]): Promise<SendSmsResult[]> {
    const results: SendSmsResult[] = [];
    for (const m of messages) {
      results.push(await this.sendSms(m.to, m.message));
    }
    return results;
  }

  validateConfiguration() {
    return { ok: true };
  }

  checkUnicodeSupport() {
    return true;
  }
}
