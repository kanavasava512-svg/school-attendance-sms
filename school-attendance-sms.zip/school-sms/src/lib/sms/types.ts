export type SendSmsResult = {
  success: boolean;
  providerMessageId?: string;
  error?: string;
  mock?: boolean;
};

export interface SmsProvider {
  sendSms(to: string, message: string): Promise<SendSmsResult>;
  sendBulkSms(messages: { to: string; message: string }[]): Promise<SendSmsResult[]>;
  validateConfiguration(): { ok: boolean; error?: string };
  checkUnicodeSupport(): boolean;
}
