import { SmsProvider } from './types';
import { MockSmsProvider } from './mockProvider';
import { RealSmsProvider } from './realProvider';

export function getSmsProvider(): SmsProvider {
  const mock = (process.env.MOCK_SMS ?? 'true').toLowerCase() !== 'false';
  return mock ? new MockSmsProvider() : new RealSmsProvider();
}

export function isMockMode(): boolean {
  return (process.env.MOCK_SMS ?? 'true').toLowerCase() !== 'false';
}

export * from './types';
