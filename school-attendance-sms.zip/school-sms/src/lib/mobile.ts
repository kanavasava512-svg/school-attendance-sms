// Indian mobile number normalization & validation.
// Accepts: 9876543210, +919876543210, 919876543210, with spaces/dashes.
// Canonical stored form: +91XXXXXXXXXX (10 digits, first digit 6-9).

export type MobileCheck =
  | { kind: 'valid'; normalized: string }
  | { kind: 'invalid'; reason: string }
  | { kind: 'missing' };

export function normalizeMobile(raw: unknown): MobileCheck {
  if (raw === null || raw === undefined) return { kind: 'missing' };
  let s = String(raw).trim();
  if (s === '') return { kind: 'missing' };

  // Excel sometimes stores numbers as floats (e.g. 9876543210.0) or with .0 suffix
  s = s.replace(/\.0+$/, '');
  // strip spaces, dashes, parentheses
  s = s.replace(/[\s\-()]/g, '');

  if (!/^[+0-9]+$/.test(s)) {
    return { kind: 'invalid', reason: 'Contains non-numeric characters' };
  }

  if (s.startsWith('+91')) s = s.slice(3);
  else if (s.startsWith('0091')) s = s.slice(4);
  else if (s.startsWith('91') && s.length === 12) s = s.slice(2);
  else if (s.startsWith('0') && s.length === 11) s = s.slice(1);

  if (!/^\d{10}$/.test(s)) {
    return { kind: 'invalid', reason: `Expected 10 digits, got ${s.length}` };
  }
  if (!/^[6-9]/.test(s)) {
    return { kind: 'invalid', reason: 'Indian mobile numbers start with 6-9' };
  }

  return { kind: 'valid', normalized: `+91${s}` };
}

export function displayMobile(normalized: string | null | undefined): string {
  if (!normalized) return '—';
  return normalized.replace('+91', '');
}
