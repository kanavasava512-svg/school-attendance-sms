import pdfParse from 'pdf-parse';
import { findClassFromText } from './classes';

export type ParsedAttendanceRow = {
  childUid: string | null;
  studentName: string;
  section: string | null;
  status: 'PRESENT' | 'ABSENT' | 'UNKNOWN';
  rawStatus: string;
};

export type PdfParseResult = {
  classSlug: string | null;
  classLabelDetected: string | null;
  attendanceDate: string | null; // ISO yyyy-mm-dd
  schoolCode: string | null;
  rows: ParsedAttendanceRow[];
  requiresManualVerification: boolean;
  extractionMode: 'text' | 'ocr_unavailable';
  rawTextLength: number;
}

function normalizeStatus(raw: string): 'PRESENT' | 'ABSENT' | 'UNKNOWN' {
  const s = raw.trim().toLowerCase();
  if (s === 'present') return 'PRESENT';
  if (s === 'absent') return 'ABSENT';
  return 'UNKNOWN';
}

function parseDate(text: string): string | null {
  // Matches "Date : 11-09-2026" or "Date: 11/09/2026"
  const m = text.match(/date\s*[:.]?\s*(\d{1,2})[-/](\d{1,2})[-/](\d{4})/i);
  if (!m) return null;
  const [, dd, mm, yyyy] = m;
  return `${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
}

function parseSchoolCode(text: string): string | null {
  const m = text.match(/school\s*code\s*[:.]?\s*(\d{6,})/i);
  return m ? m[1] : null;
}

export async function parseAttendancePdf(buffer: Buffer): Promise<PdfParseResult> {
  const data = await pdfParse(buffer);
  const text = data.text || '';

  if (text.trim().length < 20) {
    // Text layer is empty/near-empty — this is a scanned/image PDF.
    // A full OCR pipeline (e.g. render pages to images with pdf-to-img, then run
    // tesseract.js) is intentionally not wired up in this build because it needs
    // native canvas/image rendering that isn't available in every deployment
    // target. The interface below is ready for that provider to be dropped in.
    return {
      classSlug: null,
      classLabelDetected: null,
      attendanceDate: null,
      schoolCode: null,
      rows: [],
      requiresManualVerification: true,
      extractionMode: 'ocr_unavailable',
      rawTextLength: text.length,
    };
  }

  const classMatch = text.match(/class\s*[:.]?\s*([A-Za-z0-9 ]{1,15})/i);
  const classDef = findClassFromText(text);
  const attendanceDate = parseDate(text);
  const schoolCode = parseSchoolCode(text);

  // Row pattern: <UID 6+ digits>  <NAME words>  <Section letter/short code>  <Present|Absent>
  // Built from the demo PDF's table layout: "240105007022010021 ABDEMAN K SAMA A ABSENT"
  const rowPattern = /(\d{6,})\s+([A-Za-z][A-Za-z .]*?)\s+([A-Za-z0-9]{1,3})\s+(present|absent)\b/gi;
  const rows: ParsedAttendanceRow[] = [];
  let match: RegExpExecArray | null;
  while ((match = rowPattern.exec(text)) !== null) {
    const [, uid, name, section, statusRaw] = match;
    rows.push({
      childUid: uid,
      studentName: name.trim(),
      section: section.trim(),
      status: normalizeStatus(statusRaw),
      rawStatus: statusRaw,
    });
  }

  return {
    classSlug: classDef?.slug ?? null,
    classLabelDetected: classMatch ? classMatch[1].trim() : null,
    attendanceDate,
    schoolCode,
    rows,
    requiresManualVerification: rows.length === 0,
    extractionMode: 'text',
    rawTextLength: text.length,
  };
}
