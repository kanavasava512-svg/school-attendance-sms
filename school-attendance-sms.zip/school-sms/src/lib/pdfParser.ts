import pdfParse from 'pdf-parse';
import { findClassFromText } from './classes';

export type ParsedAttendanceRow = {
  childUid: string | null;
  studentName: string;
  section: string | null;
  status: 'PRESENT' | 'ABSENT' | 'UNKNOWN';
  rawStatus: string;
};

export type PdfParseResult = {
  classSlug: string | null;
  classLabelDetected: string | null;
  attendanceDate: string | null;
  schoolCode: string | null;
  rows: ParsedAttendanceRow[];
  requiresManualVerification: boolean;
  extractionMode: 'text' | 'ocr_unavailable';
  rawTextLength: number;
  rawTextSample: string; // first part of extracted text, for troubleshooting
};

function normalizeStatus(raw: string): 'PRESENT' | 'ABSENT' | 'UNKNOWN' {
  const s = raw.trim().toLowerCase();
  if (s === 'present') return 'PRESENT';
  if (s === 'absent') return 'ABSENT';
  return 'UNKNOWN';
}

function parseDate(text: string): string | null {
  const m = text.match(/date\s*[:.]?\s*(\d{1,2})[-/](\d{1,2})[-/](\d{4})/i);
  if (!m) return null;
  const [, dd, mm, yyyy] = m;
  return `${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
}

function parseSchoolCode(text: string): string | null {
  const m = text.match(/school\s*code\s*[:.]?\s*(\d{6,})/i);
  return m ? m[1] : null;
}

function cleanExtractedText(text: string): string {
  return text
    .replace(/\u00a0/g, ' ')
    .replace(/[\u2000-\u200b\ufeff]/g, ' ')
    .replace(/\r\n?/g, '\n')
    // Some PDF extractors use form-feed/page-break characters.
    .replace(/\f/g, '\n');
}

function makeRow(uid: string, beforeStatus: string, statusRaw: string): ParsedAttendanceRow | null {
  let middle = beforeStatus
    .replace(/^\s*(?:child\s+uid|student\s+name|section|status)\s+/i, '')
    .replace(/\s+/g, ' ')
    .trim();

  if (!middle) return null;

  const tokens = middle.split(/\s+/).filter(Boolean);

  // The report format has Section immediately before Present/Absent.
  // If it is a short token (normally A), remove it from the student name.
  let section: string | null = null;
  if (
    tokens.length > 1 &&
    /^[A-Za-z0-9]{1,3}$/.test(tokens[tokens.length - 1]) &&
    !/^(present|absent)$/i.test(tokens[tokens.length - 1])
  ) {
    section = tokens.pop()!;
  }

  const studentName = tokens.join(' ').trim();
  // Guard: a real name is short and has no header/label text such as "School Name:"
  if (studentName.length > 60 || /[:|]/.test(studentName)) return null;
  if (!studentName || /^(student\s+name|child\s+uid)$/i.test(studentName)) return null;

  return {
    childUid: uid,
    studentName,
    section,
    status: normalizeStatus(statusRaw),
    rawStatus: statusRaw,
  };
}

function parseRowsLineBased(text: string): ParsedAttendanceRow[] {
  const rows: ParsedAttendanceRow[] = [];

  /*
   * IMPORTANT:
   * Attendance PDFs can be extracted in two common ways:
   *
   * 1) One complete row per line:
   *    240... ABDEMAN K SAMA A ABSENT
   *
   * 2) The same row split across several lines:
   *    240...
   *    ABDEMAN K SAMA
   *    A
   *    ABSENT
   *
   * The old parser only handled case #1. The uploaded school attendance
   * report can produce case #2 depending on the PDF text layer. We therefore
   * anchor on Child UID and read until the next UID, then locate Present/Absent.
   */

  const normalized = text
    .replace(/\u00a0/g, ' ')
    .replace(/[\u2000-\u200b\ufeff]/g, ' ')
    .replace(/\r\n?/g, '\n')
    .replace(/\f/g, '\n');

  // Remove zero-width spacing while preserving useful line boundaries.
  const lines = normalized
    .split('\n')
    .map((line) => line.replace(/\s+/g, ' ').trim())
    .filter(Boolean);

  // First pass: row-oriented parsing, including rows split over multiple lines.
  const uidRe = /^\d{10,}$/;
  const inlineUidRe = /^(\d{10,})\s+(.+)$/;

  let currentUid: string | null = null;
  let currentParts: string[] = [];

  const flush = () => {
    if (!currentUid || currentParts.length === 0) return;

    const block = currentParts.join(' ').replace(/\s+/g, ' ').trim();

    // Status is normally the last meaningful word in the row block.
    const statusMatch = block.match(/(?:^|\s)(present|absent)\s*$/i);
    if (!statusMatch) {
      currentUid = null;
      currentParts = [];
      return;
    }

    const beforeStatus = block.slice(0, statusMatch.index ?? 0).trim();
    const row = makeRow(currentUid, beforeStatus, statusMatch[1]);
    if (row) rows.push(row);

    currentUid = null;
    currentParts = [];
  };

  for (const line of lines) {
    if (uidRe.test(line)) {
      flush();
      currentUid = line;
      currentParts = [];
      continue;
    }

    const inline = line.match(inlineUidRe);
    if (inline) {
      flush();
      currentUid = inline[1];
      currentParts = [inline[2]];
      continue;
    }

    if (currentUid) {
      // Ignore table headers and obvious page/report labels.
      if (
        /^(child\s+uid|student\s+name|section|status)$/i.test(line) ||
        /^student\s+attendance\s+report$/i.test(line)
      ) {
        continue;
      }
      currentParts.push(line);
    }
  }
  flush();

  // De-duplicate rows by UID + status/name. This protects against duplicate
  // text layers in some PDFs.
  const unique = new Map<string, ParsedAttendanceRow>();
  for (const row of rows) {
    const key = `${row.childUid}|${row.studentName.toLowerCase()}|${row.status}`;
    if (!unique.has(key)) unique.set(key, row);
  }

  if (unique.size > 0) return Array.from(unique.values());

  // Fallback #1: whitespace-collapsed text where rows are not separated.
  const collapsed = normalized.replace(/\s+/g, ' ');
  const rowPattern =
    /(\d{10,})\s+(.+?)\s+([A-Za-z0-9]{1,3})\s+(present|absent)\b/gi;

  let match: RegExpExecArray | null;
  while ((match = rowPattern.exec(collapsed)) !== null) {
    const [, uid, name, section, statusRaw] = match;
    const studentName = name.trim();
    if (!studentName || /^(child|uid|student|name|section|status)$/i.test(studentName)) continue;

    const key = `${uid}|${studentName.toLowerCase()}|${normalizeStatus(statusRaw)}`;
    if (!unique.has(key)) {
      unique.set(key, {
        childUid: uid,
        studentName,
        section: section.trim(),
        status: normalizeStatus(statusRaw),
        rawStatus: statusRaw,
      });
    }
  }

  if (unique.size > 0) return Array.from(unique.values());

  // Fallback #2: handle a PDF extractor that puts UID, name, section and
  // status on separate whitespace tokens without reliable line breaks.
  const tokenized = collapsed.split(/\s+/).filter(Boolean);
  for (let i = 0; i < tokenized.length; i++) {
    if (!/^\d{10,}$/.test(tokenized[i])) continue;

    const uid = tokenized[i];
    const parts: string[] = [];

    for (let j = i + 1; j < tokenized.length && parts.length < 30; j++) {
      if (/^\d{10,}$/.test(tokenized[j])) break;
      parts.push(tokenized[j]);
      if (/^(present|absent)$/i.test(tokenized[j])) {
        const statusRaw = tokenized[j];
        const beforeStatus = parts.slice(0, -1).join(' ');
        const row = makeRow(uid, beforeStatus, statusRaw);
        if (row) {
          const key = `${uid}|${row.studentName.toLowerCase()}|${row.status}`;
          unique.set(key, row);
        }
        break;
      }
    }
  }

  return Array.from(unique.values());
}

// Last-resort parser for text where table cells are glued together with no
// separators, e.g. "240105007022010021ABDEMAN K SAMAAABSENT".
function parseGlued(text: string): ParsedAttendanceRow[] {
  const rows: ParsedAttendanceRow[] = [];
  const glued = /(\d{12,})([A-Za-z][A-Za-z .]*?)([A-Za-z0-9])(present|absent)/gi;
  let g: RegExpExecArray | null;
  while ((g = glued.exec(text)) !== null) {
    const [, uid, name, section, statusRaw] = g;
    rows.push({
      childUid: uid,
      studentName: name.trim(),
      section: section.trim(),
      status: normalizeStatus(statusRaw),
      rawStatus: statusRaw,
    });
  }
  return rows;
}

function parseRows(text: string): ParsedAttendanceRow[] {
  const rows = parseRowsLineBased(text);
  if (rows.length <= 1) {
    const glued = parseGlued(text);
    if (glued.length > rows.length) return glued;
  }
  return rows;
}

// pdf-parse's default page renderer glues table cells on the same line together
// with NO separator. This renderer inserts a space between text items on the
// same line and a newline between lines.
async function renderPageWithSpaces(pageData: any): Promise<string> {
  const content = await pageData.getTextContent({ normalizeWhitespace: true, disableCombineTextItems: false });
  let out = '';
  let lastY: number | null = null;
  for (const item of content.items as Array<{ str: string; transform: number[] }>) {
    if (!item.str || !item.str.trim()) continue;
    const y = item.transform[5];
    if (lastY === null) out += item.str;
    else if (Math.abs(lastY - y) < 3) out += ' ' + item.str;
    else out += '\n' + item.str;
    lastY = y;
  }
  return out;
}

export async function parseAttendancePdf(buffer: Buffer): Promise<PdfParseResult> {
  const data = await pdfParse(buffer, { pagerender: renderPageWithSpaces } as any);
  const text = cleanExtractedText(data.text || '');

  if (text.trim().length < 20) {
    return {
      classSlug: null,
      classLabelDetected: null,
      attendanceDate: null,
      schoolCode: null,
      rows: [],
      requiresManualVerification: true,
      extractionMode: 'ocr_unavailable',
      rawTextLength: text.length,
      rawTextSample: text.slice(0, 600),
    };
  }

  const classMatch = text.match(/class\s*[:.]?\s*([A-Za-z0-9 ]{1,15})/i);
  const classDef = findClassFromText(text);
  const attendanceDate = parseDate(text);
  const schoolCode = parseSchoolCode(text);
  const rows = parseRows(text);

  return {
    classSlug: classDef?.slug ?? null,
    classLabelDetected: classMatch ? classMatch[1].trim() : null,
    attendanceDate,
    schoolCode,
    rows,
    requiresManualVerification: rows.length === 0,
    extractionMode: 'text',
    rawTextLength: text.length,
    rawTextSample: text.slice(0, 600),
  };
}
