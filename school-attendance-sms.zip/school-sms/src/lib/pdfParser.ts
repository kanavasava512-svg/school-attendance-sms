import pdfParse from 'pdf-parse';
import { findClassFromText } from './classes';

export type ParsedAttendanceRow = {
  childUid: string | null;
  studentName: string;
  section: string | null;
  status: 'PRESENT' | 'ABSENT' | 'UNKNOWN';
  rawStatus: string;
};

export type PdfParseResult = {
  classSlug: string | null;
  classLabelDetected: string | null;
  attendanceDate: string | null;
  schoolCode: string | null;
  rows: ParsedAttendanceRow[];
  requiresManualVerification: boolean;
  extractionMode: 'text' | 'ocr_unavailable';
  rawTextLength: number;
};

function normalizeStatus(raw: string): 'PRESENT' | 'ABSENT' | 'UNKNOWN' {
  const s = raw.trim().toLowerCase();
  if (s === 'present') return 'PRESENT';
  if (s === 'absent') return 'ABSENT';
  return 'UNKNOWN';
}

function parseDate(text: string): string | null {
  const m = text.match(/date\s*[:.]?\s*(\d{1,2})[-/](\d{1,2})[-/](\d{4})/i);
  if (!m) return null;
  const [, dd, mm, yyyy] = m;
  return `${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
}

function parseSchoolCode(text: string): string | null {
  const m = text.match(/school\s*code\s*[:.]?\s*(\d{6,})/i);
  return m ? m[1] : null;
}

function cleanExtractedText(text: string): string {
  return text
    .replace(/\u00a0/g, ' ')
    .replace(/[\u2000-\u200b\ufeff]/g, ' ')
    .replace(/\r/g, '\n')
    .replace(/[ \t]+/g, ' ');
}

function makeRow(
  childUid: string,
  studentName: string,
  section: string | null,
  rawStatus: string
): ParsedAttendanceRow | null {
  const name = studentName.replace(/\s+/g, ' ').trim();
  if (!name) return null;

  return {
    childUid,
    studentName: name,
    section: section?.trim() || null,
    status: normalizeStatus(rawStatus),
    rawStatus: rawStatus.trim(),
  };
}

function parseRows(text: string): ParsedAttendanceRow[] {
  const rows: ParsedAttendanceRow[] = [];
  const lines = text
    .split(/\n+/)
    .map((line) => line.replace(/\s+/g, ' ').trim())
    .filter(Boolean);

  // Format A: one complete student record on one line.
  for (const line of lines) {
    const m = line.match(/^(\d{10,})\s+(.+?)\s+(present|absent)\s*$/i);
    if (!m) continue;

    const childUid = m[1];
    const middle = m[2].trim();
    const tokens = middle.split(/\s+/).filter(Boolean);

    let section: string | null = null;
    if (tokens.length > 1 && /^[A-Za-z0-9]{1,3}$/.test(tokens[tokens.length - 1])) {
      section = tokens.pop()!;
    }

    const row = makeRow(childUid, tokens.join(' '), section, m[3]);
    if (row) rows.push(row);
  }

  if (rows.length > 0) return rows;

  // Format B: pdf-parse often extracts the table vertically:
  //
  // UID
  // STUDENT NAME
  // A
  // ABSENT
  //
  // The supplied school attendance PDF uses this layout.
  for (let i = 0; i < lines.length; i++) {
    const uidMatch = lines[i].match(/^(\d{10,})$/);
    if (!uidMatch) continue;

    const childUid = uidMatch[1];
    const parts: string[] = [];
    let status: string | null = null;

    for (let j = i + 1; j < Math.min(i + 6, lines.length); j++) {
      const current = lines[j];

      const statusMatch = current.match(/^(present|absent)$/i);
      if (statusMatch) {
        status = statusMatch[1];
        i = j;
        break;
      }

      // Also support "A ABSENT" or "student name A ABSENT" on one line.
      const inlineStatus = current.match(/^(.*?)\s+([A-Za-z0-9]{1,3})\s+(present|absent)$/i);
      if (inlineStatus) {
        parts.push(inlineStatus[1]);
        parts.push(`__SECTION__${inlineStatus[2]}`);
        status = inlineStatus[3];
        i = j;
        break;
      }

      parts.push(current);
    }

    if (!status) continue;

    let section: string | null = null;
    const sectionIndex = parts.findIndex((p) => p.startsWith('__SECTION__'));
    if (sectionIndex >= 0) {
      section = parts[sectionIndex].replace('__SECTION__', '');
      parts.splice(sectionIndex, 1);
    } else if (parts.length > 1 && /^[A-Za-z0-9]{1,3}$/.test(parts[parts.length - 1])) {
      section = parts.pop()!;
    }

    const row = makeRow(childUid, parts.join(' '), section, status);
    if (row) rows.push(row);
  }

  if (rows.length > 0) return rows;

  // Format C: all table columns collapsed into a single text stream.
  const rowPattern =
    /(\d{10,})\s+(.+?)\s+([A-Za-z0-9]{1,3})\s+(present|absent)\b/gi;
  let match: RegExpExecArray | null;
  while ((match = rowPattern.exec(text)) !== null) {
    const [, uid, name, section, statusRaw] = match;
    const row = makeRow(uid, name, section, statusRaw);
    if (row) rows.push(row);
  }

  return rows;
}

export async function parseAttendancePdf(buffer: Buffer): Promise<PdfParseResult> {
  const data = await pdfParse(buffer);
  const text = cleanExtractedText(data.text || '');

  if (text.trim().length < 20) {
    return {
      classSlug: null,
      classLabelDetected: null,
      attendanceDate: null,
      schoolCode: null,
      rows: [],
      requiresManualVerification: true,
      extractionMode: 'ocr_unavailable',
      rawTextLength: text.length,
    };
  }

  const classMatch = text.match(/class\s*[:.]?\s*([A-Za-z0-9 ]{1,15})/i);
  const classDef = findClassFromText(text);
  const attendanceDate = parseDate(text);
  const schoolCode = parseSchoolCode(text);
  const rows = parseRows(text);

  return {
    classSlug: classDef?.slug ?? null,
    classLabelDetected: classMatch ? classMatch[1].trim() : null,
    attendanceDate,
    schoolCode,
    rows,
    requiresManualVerification: rows.length === 0,
    extractionMode: 'text',
    rawTextLength: text.length,
  };
}
