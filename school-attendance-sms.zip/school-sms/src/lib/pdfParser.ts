import pdfParse from 'pdf-parse';
import { findClassFromText } from './classes';

export type ParsedAttendanceRow = {
  childUid: string | null;
  studentName: string;
  section: string | null;
  status: 'PRESENT' | 'ABSENT' | 'UNKNOWN';
  rawStatus: string;
};

export type PdfParseResult = {
  classSlug: string | null;
  classLabelDetected: string | null;
  attendanceDate: string | null;
  schoolCode: string | null;
  rows: ParsedAttendanceRow[];
  requiresManualVerification: boolean;
  extractionMode: 'text' | 'ocr_unavailable';
  rawTextLength: number;
};

function normalizeStatus(raw: string): 'PRESENT' | 'ABSENT' | 'UNKNOWN' {
  const s = raw.trim().toLowerCase();
  if (s === 'present') return 'PRESENT';
  if (s === 'absent') return 'ABSENT';
  return 'UNKNOWN';
}

function parseDate(text: string): string | null {
  const m = text.match(/date\s*[:.]?\s*(\d{1,2})[-/](\d{1,2})[-/](\d{4})/i);
  if (!m) return null;
  const [, dd, mm, yyyy] = m;
  return `${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
}

function parseSchoolCode(text: string): string | null {
  const m = text.match(/school\s*code\s*[:.]?\s*(\d{6,})/i);
  return m ? m[1] : null;
}

function cleanExtractedText(text: string): string {
  return text
    .replace(/\u00a0/g, ' ')
    .replace(/[\u2000-\u200b\ufeff]/g, ' ')
    .replace(/\r/g, '\n');
}

function parseRows(text: string): ParsedAttendanceRow[] {
  const rows: ParsedAttendanceRow[] = [];

  // The supplied attendance PDF has one table row per line. Keep this parser
  // tolerant of PDF text-extraction differences in whitespace and fonts.
  const lines = text.split(/\n+/).map((line) => line.replace(/\s+/g, ' ').trim()).filter(Boolean);

  for (const line of lines) {
    // UID + name/section + final Present/Absent. UID is the strongest anchor.
    const m = line.match(/^(\d{10,})\s+(.+?)\s+(present|absent)\s*$/i);
    if (!m) continue;

    const childUid = m[1];
    const middle = m[2].trim();
    const statusRaw = m[3];
    const tokens = middle.split(/\s+/).filter(Boolean);

    // Demo/report format ends with a short section code (normally A).
    let section: string | null = null;
    if (tokens.length > 1 && /^[A-Za-z0-9]{1,3}$/.test(tokens[tokens.length - 1])) {
      section = tokens.pop()!;
    }

    const studentName = tokens.join(' ').trim();
    if (!studentName) continue;

    rows.push({
      childUid,
      studentName,
      section,
      status: normalizeStatus(statusRaw),
      rawStatus: statusRaw,
    });
  }

  // Fallback for extractors that collapse table rows into a single line.
  if (rows.length === 0) {
    const rowPattern = /(\d{10,})\s+([A-Za-z][A-Za-z .]*?)\s+([A-Za-z0-9]{1,3})\s+(present|absent)\b/gi;
    let match: RegExpExecArray | null;
    while ((match = rowPattern.exec(text)) !== null) {
      const [, uid, name, section, statusRaw] = match;
      rows.push({
        childUid: uid,
        studentName: name.trim(),
        section: section.trim(),
        status: normalizeStatus(statusRaw),
        rawStatus: statusRaw,
      });
    }
  }

  return rows;
}

export async function parseAttendancePdf(buffer: Buffer): Promise<PdfParseResult> {
  const data = await pdfParse(buffer);
  const text = cleanExtractedText(data.text || '');

  if (text.trim().length < 20) {
    return {
      classSlug: null,
      classLabelDetected: null,
      attendanceDate: null,
      schoolCode: null,
      rows: [],
      requiresManualVerification: true,
      extractionMode: 'ocr_unavailable',
      rawTextLength: text.length,
    };
  }

  const classMatch = text.match(/class\s*[:.]?\s*([A-Za-z0-9 ]{1,15})/i);
  const classDef = findClassFromText(text);
  const attendanceDate = parseDate(text);
  const schoolCode = parseSchoolCode(text);
  const rows = parseRows(text);

  return {
    classSlug: classDef?.slug ?? null,
    classLabelDetected: classMatch ? classMatch[1].trim() : null,
    attendanceDate,
    schoolCode,
    rows,
    requiresManualVerification: rows.length === 0,
    extractionMode: 'text',
    rawTextLength: text.length,
  };
}
