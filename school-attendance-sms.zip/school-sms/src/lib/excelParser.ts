import * as XLSX from 'xlsx';
import { findClassBySheetName, sheetIsIgnorable } from './classes';
import { normalizeMobile } from './mobile';

export type ParsedStudentRow = {
  rowNumber: number;
  childUid: string | null;
  studentName: string | null;
  studentNameGujarati: string | null;
  section: string | null;
  mobileRaw: string | null;
  mobileNormalized: string | null;
  mobileStatus: 'valid' | 'invalid' | 'missing';
  mobileInvalidReason?: string;
  error?: string;
};

export type ParsedClassSheet = {
  sheetName: string;
  classSlug: string | null;
  rows: ParsedStudentRow[];
};

export type ExcelParseResult = {
  classes: ParsedClassSheet[];
  unknownSheets: string[]; // sheets with data but no matching class (excluding ignorable ones)
};

const containsGujarati = (s: string) => /[\u0A80-\u0AFF]/.test(s);

function headerIndex(headerRow: unknown[], patterns: RegExp[], exclude?: RegExp): number {
  for (let i = 0; i < headerRow.length; i++) {
    const v = headerRow[i];
    if (typeof v !== 'string') continue;
    const s = v.trim();
    if (!s) continue;
    if (exclude && exclude.test(s)) continue;
    if (patterns.some((p) => p.test(s))) return i;
  }
  return -1;
}

function findHeaderRow(rows: unknown[][]): number {
  for (let r = 0; r < Math.min(rows.length, 15); r++) {
    const row = rows[r];
    if (row.some((c) => typeof c === 'string' && /child\s*uid/i.test(c))) {
      return r;
    }
  }
  return -1;
}

export function parseStudentWorkbook(buffer: Buffer): ExcelParseResult {
  const workbook = XLSX.read(buffer, { type: 'buffer', cellDates: false });
  const classes: ParsedClassSheet[] = [];
  const unknownSheets: string[] = [];

  for (const sheetName of workbook.SheetNames) {
    if (sheetIsIgnorable(sheetName)) continue;

    const sheet = workbook.Sheets[sheetName];
    const rows: unknown[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: null, raw: true });

    const headerRowIdx = findHeaderRow(rows);
    if (headerRowIdx === -1) {
      // Sheet has no recognizable student table — ignore silently unless it has
      // any non-empty cell, in which case flag it for the Principal to review.
      const hasContent = rows.some((r) => r.some((c) => c !== null && c !== ''));
      if (hasContent) unknownSheets.push(sheetName);
      continue;
    }

    const classDef = findClassBySheetName(sheetName);
    const header = rows[headerRowIdx];

    const idx = {
      srNo: headerIndex(header, [/^sr\.?\s*no\.?$/i]),
      childUid: headerIndex(header, [/child\s*uid/i]),
      studentName: headerIndex(header, [/^student\s*name$/i, /^name$/i], /gujarat/i),
      gujaratiName: headerIndex(header, [/gujarat/i, /ગુજરાતી/]),
      std: headerIndex(header, [/^std$/i, /^class$/i]),
      section: headerIndex(header, [/section/i]),
      mobile: headerIndex(header, [/mobile/i, /phone/i, /contact/i]),
    };

    const parsedRows: ParsedStudentRow[] = [];

    for (let r = headerRowIdx + 1; r < rows.length; r++) {
      const row = rows[r];
      if (!row || row.every((c) => c === null || c === '')) continue;

      const childUidRaw = idx.childUid >= 0 ? row[idx.childUid] : null;
      const nameRaw = idx.studentName >= 0 ? row[idx.studentName] : null;

      if ((childUidRaw === null || childUidRaw === '') && (nameRaw === null || nameRaw === '')) {
        // Blank separator row — skip without treating as an error.
        continue;
      }

      const childUid = childUidRaw !== null ? String(childUidRaw).trim() : null;
      const studentName = nameRaw !== null ? String(nameRaw).trim() : null;
      let gujaratiName = idx.gujaratiName >= 0 && row[idx.gujaratiName] !== null
        ? String(row[idx.gujaratiName]).trim()
        : null;
      if (gujaratiName && !containsGujarati(gujaratiName)) {
        // Column matched by header name but content isn't actually Gujarati text —
        // treat as absent rather than risk sending an English name as "Gujarati".
        gujaratiName = null;
      }
      const section = idx.section >= 0 && row[idx.section] !== null ? String(row[idx.section]).trim() : null;
      const mobileRaw = idx.mobile >= 0 && row[idx.mobile] !== null ? String(row[idx.mobile]) : null;

      const mobileCheck = normalizeMobile(mobileRaw);

      let error: string | undefined;
      if (!childUid) error = 'Missing Child UID';
      else if (!studentName) error = 'Missing Student Name';

      parsedRows.push({
        rowNumber: r + 1,
        childUid,
        studentName,
        studentNameGujarati: gujaratiName,
        section,
        mobileRaw,
        mobileNormalized: mobileCheck.kind === 'valid' ? mobileCheck.normalized : null,
        mobileStatus: mobileCheck.kind,
        mobileInvalidReason: mobileCheck.kind === 'invalid' ? mobileCheck.reason : undefined,
        error,
      });
    }

    if (!classDef) {
      if (parsedRows.length > 0) unknownSheets.push(sheetName);
      continue;
    }

    classes.push({ sheetName, classSlug: classDef.slug, rows: parsedRows });
  }

  return { classes, unknownSheets };
}
