'use client';

export default function StatusBadge({ status }: { status: string | null | undefined }) {
  if (!status) return <span className="badge badge-pending">—</span>;
  const map: Record<string, string> = {
    PRESENT: 'badge-present',
    ABSENT: 'badge-absent',
    SENT: 'badge-sent',
    MOCK_SENT: 'badge-sent',
    FAILED: 'badge-failed',
    PENDING: 'badge-pending',
    SKIPPED: 'badge-pending',
    ALREADY_SENT: 'badge-pending',
  };
  const labelMap: Record<string, string> = {
    PRESENT: 'હાજર',
    ABSENT: 'ગેરહાજર',
    SENT: 'SMS મોકલાયો',
    MOCK_SENT: 'SMS મોકલાયો (Demo)',
    FAILED: 'નિષ્ફળ',
    PENDING: 'બાકી',
    SKIPPED: 'છોડેલ',
    ALREADY_SENT: 'પહેલેથી મોકલાયો',
  };
  return <span className={`badge ${map[status] ?? 'badge-pending'}`}>{labelMap[status] ?? status}</span>;
}
