'use client';

export default function ConfirmModal({
  open,
  title,
  children,
  confirmLabel,
  cancelLabel = 'રદ કરો',
  onConfirm,
  onCancel,
  loading,
  danger,
}: {
  open: boolean;
  title: string;
  children: React.ReactNode;
  confirmLabel: string;
  cancelLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
  loading?: boolean;
  danger?: boolean;
}) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-end md:items-center justify-center bg-black/40 p-0 md:p-4">
      <div className="bg-white rounded-t-2xl md:rounded-2xl w-full md:max-w-md p-5 space-y-4 max-h-[85vh] overflow-y-auto">
        <h3 className="text-lg font-semibold">{title}</h3>
        <div className="text-sm text-gray-700 space-y-2">{children}</div>
        <div className="flex gap-3 pt-2">
          <button className="btn-secondary flex-1" onClick={onCancel} disabled={loading}>
            {cancelLabel}
          </button>
          <button
            className={`flex-1 ${danger ? 'btn-danger' : 'btn-primary'}`}
            onClick={onConfirm}
            disabled={loading}
          >
            {loading ? 'મોકલી રહ્યા છીએ...' : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
