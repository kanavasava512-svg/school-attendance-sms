'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { apiPost } from '@/lib/clientFetch';
import ToastHost from './Toast';

type NavItem = { href: string; label: string; principalOnly?: boolean; color: string; active: string };

const NAV_ITEMS: NavItem[] = [
  { href: '/dashboard', label: 'ડેશબોર્ડ', color: 'menu-blue', active: 'menu-blue-active' },
  { href: '/students', label: 'વિદ્યાર્થીઓ', color: 'menu-green', active: 'menu-green-active' },
  { href: '/excel', label: 'Excel Management', principalOnly: true, color: 'menu-orange', active: 'menu-orange-active' },
  { href: '/attendance', label: 'હાજરી', color: 'menu-purple', active: 'menu-purple-active' },
  { href: '/messages', label: 'સામાન્ય સંદેશ', principalOnly: true, color: 'menu-pink', active: 'menu-pink-active' },
  { href: '/sms-history', label: 'SMS ઇતિહાસ', color: 'menu-cyan', active: 'menu-cyan-active' },
  { href: '/reports', label: 'Reports', color: 'menu-amber', active: 'menu-amber-active' },
  { href: '/settings', label: 'સેટિંગ્સ', principalOnly: true, color: 'menu-red', active: 'menu-red-active' },
];

export default function AppShell({
  role,
  name,
  children,
}: {
  role: 'PRINCIPAL' | 'TEACHER';
  name: string;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await apiPost('/api/auth/logout');
    router.push('/login/principal');
    router.refresh();
  }

  const items = NAV_ITEMS.filter((i) => !i.principalOnly || role === 'PRINCIPAL');

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <aside className="md:w-60 bg-white border-b md:border-b-0 md:border-r border-gray-200 flex-shrink-0">
        <div className="p-4 border-b border-gray-100 flex items-center gap-2">
          <img src="/logo.png" alt="Logo" className="w-9 h-9 flex-shrink-0" />
          <div>
            <p className="font-semibold leading-tight text-sm">શ્રી નાના દિનારા-1</p>
            <p className="text-xs text-gray-500">પ્રાથમિક શાળા</p>
          </div>
        </div>
        <nav className="flex md:flex-col overflow-x-auto md:overflow-visible">
          {items.map((item) => {
            const active = pathname === item.href || pathname?.startsWith(item.href + '/');
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`px-4 py-3 text-sm whitespace-nowrap md:whitespace-normal border-b-2 md:border-b-0 md:border-l-4 transition ${
                  active ? `${item.active} font-semibold` : `${item.color} text-gray-700 hover:shadow-sm`
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="hidden md:block p-4 border-t border-gray-100 mt-2">
          <p className="text-xs text-gray-500 mb-2">
            {role === 'PRINCIPAL' ? 'આચાર્ય' : 'શિક્ષક (Viewer)'} · {name}
          </p>
          <button onClick={logout} className="btn-secondary w-full text-sm">
            લૉગઆઉટ
          </button>
        </div>
      </aside>

      <main className={`flex-1 min-w-0 p-4 md:p-6 pb-20 md:pb-6 page-theme-${pathname?.split('/')[1] || 'dashboard'}`}>{children}</main>
      <ToastHost />

      <button
        onClick={logout}
        className="md:hidden fixed bottom-4 right-4 btn-secondary shadow-lg bg-white text-sm"
      >
        લૉગઆઉટ
      </button>
    </div>
  );
}
