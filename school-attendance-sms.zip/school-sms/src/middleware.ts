import { NextRequest, NextResponse } from 'next/server';
import { verifyTokenEdge, SESSION_COOKIE_NAME } from '@/lib/auth';

// Server-side route protection. This is the enforcement layer required by the
// spec's "Teacher must not be able to call protected API endpoints directly" and
// "do not only hide buttons in frontend" rules. Individual API routes still
// re-check the role themselves (defense in depth) — this middleware is the
// first gate for both pages and APIs.

const PUBLIC_PATHS = ['/login/principal', '/login/teacher', '/api/auth', '/_next', '/favicon.ico'];

// Routes only the Principal may reach at all (write-side pages/APIs).
const PRINCIPAL_ONLY_PREFIXES = [
  '/excel',
  '/settings',
  '/api/excel',
  '/api/settings',
  '/api/teachers',
  '/api/sms/attendance/send',
  '/api/sms/general/send',
  '/api/attendance/upload-pdf',
  '/api/attendance/manual-match',
];

function isPublic(pathname: string) {
  return PUBLIC_PATHS.some((p) => pathname.startsWith(p)) || pathname === '/';
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (isPublic(pathname)) return NextResponse.next();

  const token = req.cookies.get(SESSION_COOKIE_NAME)?.value;
  const session = token ? await verifyTokenEdge(token) : null;

  if (!session) {
    if (pathname.startsWith('/api/')) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }
    return NextResponse.redirect(new URL('/login/principal', req.url));
  }

  const isPrincipalOnly = PRINCIPAL_ONLY_PREFIXES.some((p) => pathname.startsWith(p));
  if (isPrincipalOnly && session.role !== 'PRINCIPAL') {
    if (pathname.startsWith('/api/')) {
      return NextResponse.json({ error: 'Principal access required' }, { status: 403 });
    }
    return NextResponse.redirect(new URL('/dashboard', req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|.*\\.png$|.*\\.svg$).*)'],
};
