import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { normalizeMobile } from '@/lib/mobile';
import { verifySecret } from '@/lib/hash';
import { createSession } from '@/lib/auth';
import { logAudit } from '@/lib/audit';

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const check = normalizeMobile(body.mobile);
  const password = String(body.password || '');

  if (check.kind !== 'valid' || !password) {
    return NextResponse.json({ error: 'મોબાઈલ નંબર અથવા પાસવર્ડ અમાન્ય છે.' }, { status: 400 });
  }

  const teacher = await prisma.teacher.findUnique({ where: { mobile: check.normalized } });
  if (!teacher || !teacher.active || !verifySecret(password, teacher.passwordHash)) {
    return NextResponse.json({ error: 'લોગિન નિષ્ફળ. વિગતો તપાસો.' }, { status: 401 });
  }

  const session = { role: 'TEACHER' as const, sub: teacher.id, name: teacher.name };
  await createSession(session);
  await logAudit(session, 'Login');

  return NextResponse.json({ ok: true });
}
