import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { normalizeMobile } from '@/lib/mobile';
import { verifySecret } from '@/lib/hash';
import { createSession } from '@/lib/auth';
import { logAudit } from '@/lib/audit';

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const check = normalizeMobile(body.mobile);
  const code = String(body.code || '').trim();

  if (check.kind !== 'valid' || !/^\d{6}$/.test(code)) {
    return NextResponse.json({ error: 'OTP અમાન્ય છે.' }, { status: 400 });
  }

  const token = await prisma.otpToken.findFirst({
    where: { mobile: check.normalized, consumed: false, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: 'desc' },
  });

  if (!token || !verifySecret(code, token.codeHash)) {
    return NextResponse.json({ error: 'OTP ખોટો અથવા સમય પૂરો થયો છે.' }, { status: 401 });
  }

  await prisma.otpToken.update({ where: { id: token.id }, data: { consumed: true } });

  const session = { role: 'PRINCIPAL' as const, sub: check.normalized, name: 'આચાર્યશ્રી' };
  await createSession(session);
  await logAudit(session, 'Login');

  return NextResponse.json({ ok: true });
}
