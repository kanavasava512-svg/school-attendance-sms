import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { normalizeMobile } from '@/lib/mobile';
import { generateOtp, hashSecret } from '@/lib/hash';
import { getSmsProvider, isMockMode } from '@/lib/sms';

const OTP_TTL_MINUTES = 5;

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const check = normalizeMobile(body.mobile);

  if (check.kind !== 'valid') {
    return NextResponse.json({ error: 'મોબાઈલ નંબર અમાન્ય છે.' }, { status: 400 });
  }

  const principalMobileCheck = normalizeMobile(process.env.PRINCIPAL_MOBILE_NUMBER);
  if (principalMobileCheck.kind !== 'valid' || check.normalized !== principalMobileCheck.normalized) {
    // Deliberately vague to avoid revealing whether a mobile number is the
    // registered Principal number.
    return NextResponse.json({ error: 'આ મોબાઈલ નંબર માટે પ્રવેશ માન્ય નથી.' }, { status: 403 });
  }

  const code = generateOtp();
  await prisma.otpToken.create({
    data: {
      mobile: check.normalized,
      codeHash: hashSecret(code),
      expiresAt: new Date(Date.now() + OTP_TTL_MINUTES * 60 * 1000),
    },
  });

  const provider = getSmsProvider();
  await provider.sendSms(check.normalized, `તમારો OTP: ${code}. તે ${OTP_TTL_MINUTES} મિનિટ માટે માન્ય છે.`);

  const devHint = process.env.NODE_ENV !== 'production' || isMockMode();

  return NextResponse.json({
    ok: true,
    message: 'OTP મોકલાયો છે.',
    // Only surfaced outside real production sending, so the demo/dev flow is
    // usable without a configured SMS provider. Never exposed once a real
    // provider is active in production.
    devOtp: devHint ? code : undefined,
  });
}
