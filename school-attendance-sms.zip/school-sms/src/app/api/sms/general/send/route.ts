import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requirePrincipal, AuthError } from '@/lib/auth';
import { getClass } from '@/lib/classes';
import { getSmsProvider, isMockMode } from '@/lib/sms';
import { logAudit } from '@/lib/audit';

export async function POST(req: NextRequest) {
  try {
    const session = await requirePrincipal();
    const body = await req.json().catch(() => ({}));
    const classSlug = String(body.classSlug || '');
    const message = String(body.message || '').trim();
    const confirmed = body.confirmed === true;

    const classDef = getClass(classSlug);
    if (!classDef) return NextResponse.json({ error: 'ધોરણ પસંદ કરો.' }, { status: 400 });
    if (!message) return NextResponse.json({ error: 'સંદેશ ખાલી ન હોવો જોઈએ.' }, { status: 400 });
    if (!confirmed) return NextResponse.json({ error: 'પુષ્ટિ જરૂરી છે.' }, { status: 400 });

    const provider = getSmsProvider();
    const providerConfig = provider.validateConfiguration();
    if (!providerConfig.ok) return NextResponse.json({ error: providerConfig.error }, { status: 422 });

    const students = await prisma.student.findMany({ where: { className: classDef.slug, active: true } });

    // Dedupe recipients by mobile number.
    const byMobile = new Map<string, (typeof students)[number]>();
    for (const s of students) {
      if (s.mobileNumber && !byMobile.has(s.mobileNumber)) byMobile.set(s.mobileNumber, s);
    }

    // Don't send the exact same campaign message twice to the same mobile in this class.
    const priorSameMessage = await prisma.generalMessage.findMany({
      where: { className: classDef.slug, message },
      include: { recipients: true },
    });
    const alreadyMessaged = new Set<string>();
    for (const gm of priorSameMessage) {
      for (const r of gm.recipients) {
        if (r.status === 'SENT' || r.status === 'MOCK_SENT') alreadyMessaged.add(r.mobileNumber);
      }
    }

    const toSend = Array.from(byMobile.entries()).filter(([mobile]) => !alreadyMessaged.has(mobile));

    const generalMessage = await prisma.generalMessage.create({
      data: {
        className: classDef.slug,
        message,
        totalRecipients: toSend.length,
        createdBy: session.sub,
      },
    });

    let successful = 0;
    let failed = 0;

    for (const [mobile, student] of toSend) {
      const result = await provider.sendSms(mobile, message);
      const status = result.success ? (result.mock ? 'MOCK_SENT' : 'SENT') : 'FAILED';
      if (result.success) successful++;
      else failed++;

      await prisma.generalMessageRecipient.create({
        data: {
          generalMessageId: generalMessage.id,
          studentId: student.id,
          mobileNumber: mobile,
          status,
          errorMessage: result.error,
        },
      });

      await prisma.smsLog.create({
        data: {
          studentId: student.id,
          childUid: student.childUid,
          className: classDef.slug,
          mobileNumber: mobile,
          message,
          smsType: 'GENERAL',
          status,
          providerMessageId: result.providerMessageId,
          errorMessage: result.error,
          generalMessageId: generalMessage.id,
        },
      });
    }

    const skipped = byMobile.size - toSend.length;

    await prisma.generalMessage.update({
      where: { id: generalMessage.id },
      data: { successful, failed, skipped },
    });

    await logAudit(session, 'General Message Sent', {
      className: classDef.slug,
      generalMessageId: generalMessage.id,
      successful,
      failed,
      skipped,
    });

    return NextResponse.json({ ok: true, successful, failed, skipped, mock: isMockMode() });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    // eslint-disable-next-line no-console
    console.error(err);
    return NextResponse.json({ error: 'સંદેશ મોકલવામાં ભૂલ આવી.' }, { status: 500 });
  }
}
