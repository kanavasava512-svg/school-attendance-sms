import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requirePrincipal, AuthError } from '@/lib/auth';
import { getClass } from '@/lib/classes';

export async function GET(req: NextRequest) {
  try {
    await requirePrincipal();
    const { searchParams } = new URL(req.url);
    const classSlug = searchParams.get('classSlug') || '';
    const classDef = getClass(classSlug);
    if (!classDef) return NextResponse.json({ error: 'ધોરણ પસંદ કરો.' }, { status: 400 });

    const students = await prisma.student.findMany({ where: { className: classDef.slug, active: true } });
    const recipients = Array.from(
      new Map(
        students
          .filter((s) => s.mobileNumber)
          .map((s) => [s.mobileNumber!, { mobile: s.mobileNumber!, studentName: s.name }])
      ).values()
    );
    const validMobiles = new Set(recipients.map((r) => r.mobile));
    const invalidOrMissing = students.length - students.filter((s) => s.mobileNumber).length;

    return NextResponse.json({
      classSlug: classDef.slug,
      classLabel: classDef.labelGujarati,
      totalStudents: students.length,
      uniqueValidMobiles: validMobiles.size,
      invalidOrMissing,
      freeSmsRecipients: recipients,
    });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}
