import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requirePrincipal, AuthError } from '@/lib/auth';
import { getClass } from '@/lib/classes';
import { renderAttendanceSms, combineSiblingMessage, formatDateDMY } from '@/lib/smsTemplate';
import { getSmsProvider, isMockMode } from '@/lib/sms';
import { logAudit } from '@/lib/audit';

export async function POST(req: NextRequest) {
  try {
    const session = await requirePrincipal();
    const body = await req.json().catch(() => ({}));

    const classSlug = String(body.classSlug || '');
    const dateParam = String(body.date || '');
    const confirmed = body.confirmed === true;
    const resendStudentIds: string[] = Array.isArray(body.resendStudentIds) ? body.resendStudentIds : [];

    const classDef = getClass(classSlug);
    if (!classDef || !dateParam) {
      return NextResponse.json({ error: 'ધોરણ અને તારીખ જરૂરી છે.' }, { status: 400 });
    }
    if (!confirmed) {
      // Spec section 21/72: never send without explicit Principal confirmation.
      return NextResponse.json({ error: 'પુષ્ટિ જરૂરી છે.' }, { status: 400 });
    }

    const attendanceDate = new Date(`${dateParam}T00:00:00.000Z`);
    const dateLabel = formatDateDMY(attendanceDate);
    const school = (await prisma.school.findFirst()) ?? (await prisma.school.create({ data: {} }));

    // ---- FINAL SERVER-SIDE SAFETY CHECK (spec section 85) ----
    const absentRecords = await prisma.attendanceRecord.findMany({
      where: { className: classDef.slug, attendanceDate, status: 'ABSENT' },
      include: { student: true },
    });

    const existingLogs = await prisma.smsLog.findMany({
      where: { className: classDef.slug, attendanceDate, smsType: 'ATTENDANCE' },
    });
    const alreadySent = new Map(existingLogs.map((l) => [l.studentId, l]));

    const provider = getSmsProvider();
    const providerConfig = provider.validateConfiguration();
    if (!providerConfig.ok) {
      return NextResponse.json({ error: providerConfig.error }, { status: 422 });
    }
    if (!provider.checkUnicodeSupport()) {
      return NextResponse.json({ error: 'આ SMS Provider ગુજરાતી Unicode SMS support કરતું નથી.' }, { status: 422 });
    }

    type Eligible = { studentId: string; childUid: string; studentName: string; studentNameGujarati: string | null; mobile: string };
    const eligible: Eligible[] = [];
    let skippedInvalidOrMissing = 0;
    let skippedAlreadySent = 0;

    for (const r of absentRecords) {
      const s = r.student;
      const isResendRequest = resendStudentIds.includes(s.id);
      const priorLog = alreadySent.get(s.id);

      if (priorLog && !isResendRequest && (priorLog.status === 'SENT' || priorLog.status === 'MOCK_SENT')) {
        skippedAlreadySent++;
        continue;
      }
      if (!s.mobileNumber) {
        skippedInvalidOrMissing++;
        continue;
      }
      // Final safety re-check: status must literally be ABSENT right now.
      if (r.status !== 'ABSENT') continue;

      eligible.push({
        studentId: s.id,
        childUid: s.childUid,
        studentName: s.studentName,
        studentNameGujarati: s.studentNameGujarati,
        mobile: s.mobileNumber,
      });
    }

    // Group by mobile number so siblings get one combined SMS (spec section 33).
    const byMobile = new Map<string, Eligible[]>();
    for (const e of eligible) {
      const arr = byMobile.get(e.mobile) ?? [];
      arr.push(e);
      byMobile.set(e.mobile, arr);
    }

    let successful = 0;
    let failed = 0;
    const failedDetails: { studentName: string; error?: string }[] = [];

    for (const [mobile, group] of byMobile.entries()) {
      const names = group.map((g) => g.studentNameGujarati?.trim() || g.studentName);
      const message =
        group.length > 1
          ? combineSiblingMessage(school.smsTemplate, names, dateLabel, school.nameGujarati)
          : renderAttendanceSms(school.smsTemplate, {
              studentName: group[0].studentName,
              studentNameGujarati: group[0].studentNameGujarati,
              date: dateLabel,
              classSlug: classDef.slug,
              schoolNameGujarati: school.nameGujarati,
            });

      const result = await provider.sendSms(mobile, message);
      const status = result.success ? (result.mock ? 'MOCK_SENT' : 'SENT') : 'FAILED';
      if (result.success) successful += group.length;
      else {
        failed += group.length;
        group.forEach((g) => failedDetails.push({ studentName: g.studentName, error: result.error }));
      }

      for (const g of group) {
        await prisma.smsLog.create({
          data: {
            studentId: g.studentId,
            childUid: g.childUid,
            className: classDef.slug,
            attendanceDate,
            mobileNumber: mobile,
            message,
            smsType: 'ATTENDANCE',
            status,
            providerMessageId: result.providerMessageId,
            errorMessage: result.error,
          },
        });
      }
    }

    await logAudit(session, 'SMS Campaign', {
      type: 'ATTENDANCE',
      className: classDef.slug,
      date: dateParam,
      successful,
      failed,
      skippedAlreadySent,
      skippedInvalidOrMissing,
      mock: isMockMode(),
    });

    return NextResponse.json({
      ok: true,
      successful,
      failed,
      skippedAlreadySent,
      skippedInvalidOrMissing,
      failedDetails,
      mock: isMockMode(),
    });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    // eslint-disable-next-line no-console
    console.error(err);
    return NextResponse.json({ error: 'SMS મોકલવામાં ભૂલ આવી.' }, { status: 500 });
  }
}
