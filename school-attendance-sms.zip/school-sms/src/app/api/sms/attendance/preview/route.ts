import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requirePrincipal, AuthError } from '@/lib/auth';
import { getClass } from '@/lib/classes';
import { renderAttendanceSms, combineSiblingMessage, formatDateDMY } from '@/lib/smsTemplate';

export async function GET(req: NextRequest) {
  try {
    await requirePrincipal();
    const { searchParams } = new URL(req.url);
    const classSlug = searchParams.get('classSlug') || '';
    const dateParam = searchParams.get('date') || '';
    const classDef = getClass(classSlug);
    if (!classDef || !dateParam) {
      return NextResponse.json({ error: 'ધોરણ અને તારીખ જરૂરી છે.' }, { status: 400 });
    }

    const attendanceDate = new Date(`${dateParam}T00:00:00.000Z`);
    const dateLabel = formatDateDMY(attendanceDate);

    const school = (await prisma.school.findFirst()) ?? (await prisma.school.create({ data: {} }));

    const absentRecords = await prisma.attendanceRecord.findMany({
      where: { className: classDef.slug, attendanceDate, status: 'ABSENT' },
      include: { student: true },
    });

    const alreadySentLogs = await prisma.smsLog.findMany({
      where: {
        className: classDef.slug,
        attendanceDate,
        smsType: 'ATTENDANCE',
        status: { in: ['SENT', 'MOCK_SENT'] },
      },
    });
    const alreadySentStudentIds = new Set(alreadySentLogs.map((l) => l.studentId));

    let eligible = 0;
    let invalidMobile = 0;
    let missingMobile = 0;
    let alreadySent = 0;

    const items = absentRecords.map((r) => {
      const s = r.student;
      const already = alreadySentStudentIds.has(s.id);
      if (already) alreadySent++;
      else if (!s.mobileNumber) missingMobile++;
      else eligible++;

      return {
        studentId: s.id,
        childUid: s.childUid,
        studentName: s.studentName,
        studentNameGujarati: s.studentNameGujarati,
        mobileNumber: s.mobileNumber,
        alreadySent: already,
        eligible: !already && !!s.mobileNumber,
      };
    });

    // Group eligible students by mobile to preview combined sibling messages.
    const byMobile = new Map<string, typeof items>();
    for (const it of items) {
      if (!it.eligible || !it.mobileNumber) continue;
      const arr = byMobile.get(it.mobileNumber) ?? [];
      arr.push(it);
      byMobile.set(it.mobileNumber, arr);
    }

    const previewSamples = Array.from(byMobile.entries())
      .slice(0, 5)
      .map(([mobile, group]) => {
        const names = group.map((g) => g.studentNameGujarati?.trim() || g.studentName);
        const message =
          group.length > 1
            ? combineSiblingMessage(school.smsTemplate, names, dateLabel, school.nameGujarati)
            : renderAttendanceSms(school.smsTemplate, {
                studentName: group[0].studentName,
                studentNameGujarati: group[0].studentNameGujarati,
                date: dateLabel,
                classSlug: classDef.slug,
                schoolNameGujarati: school.nameGujarati,
              });
        return { mobile, students: group.map((g) => g.studentName), message };
      });

    return NextResponse.json({
      classSlug: classDef.slug,
      classLabel: classDef.labelGujarati,
      date: dateParam,
      dateLabel,
      totalAbsent: absentRecords.length,
      eligible,
      missingMobile,
      alreadySent,
      uniqueRecipients: byMobile.size,
      items,
      previewSamples,
    });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}
