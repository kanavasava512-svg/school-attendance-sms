import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireSession, AuthError } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    await requireSession();
    const { searchParams } = new URL(req.url);
    const className = searchParams.get('className') || undefined;
    const smsType = searchParams.get('smsType') || undefined;
    const status = searchParams.get('status') || undefined;
    const q = searchParams.get('q') || undefined;

    const logs = await prisma.smsLog.findMany({
      where: {
        ...(className ? { className } : {}),
        ...(smsType ? { smsType: smsType as any } : {}),
        ...(status ? { status: status as any } : {}),
        ...(q
          ? {
              OR: [
                { mobileNumber: { contains: q } },
                { childUid: { contains: q } },
                { student: { studentName: { contains: q, mode: 'insensitive' } } },
              ],
            }
          : {}),
      },
      include: { student: true },
      orderBy: { createdAt: 'desc' },
      take: 500,
    });

    return NextResponse.json({
      logs: logs.map((l) => ({
        id: l.id,
        createdAt: l.createdAt,
        className: l.className,
        studentName: l.student?.studentName,
        childUid: l.childUid,
        mobileNumber: l.mobileNumber,
        message: l.message,
        smsType: l.smsType,
        status: l.status,
        errorMessage: l.errorMessage,
      })),
    });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}
