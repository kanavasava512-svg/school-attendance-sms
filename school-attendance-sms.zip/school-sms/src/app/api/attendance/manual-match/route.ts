import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requirePrincipal, AuthError } from '@/lib/auth';
import { logAudit } from '@/lib/audit';

export async function POST(req: NextRequest) {
  try {
    const session = await requirePrincipal();
    const body = await req.json().catch(() => ({}));
    const rowId = String(body.unmatchedRowId || '');
    const studentId = body.studentId ? String(body.studentId) : null;
    const skip = Boolean(body.skip);

    const row = await prisma.unmatchedAttendanceRow.findUnique({ where: { id: rowId } });
    if (!row) return NextResponse.json({ error: 'Row not found' }, { status: 404 });

    if (!skip && studentId) {
      const status = /absent/i.test(row.rawStatus) ? 'ABSENT' : 'PRESENT';
      await prisma.attendanceRecord.upsert({
        where: { studentId_attendanceDate: { studentId, attendanceDate: row.attendanceDate } },
        update: { status, sourcePdf: row.sourcePdf ?? undefined, matchType: 'MANUAL' },
        create: {
          studentId,
          className: row.className,
          attendanceDate: row.attendanceDate,
          status,
          sourcePdf: row.sourcePdf ?? undefined,
          matchType: 'MANUAL',
        },
      });
    }

    await prisma.unmatchedAttendanceRow.update({
      where: { id: rowId },
      data: { resolved: true, resolvedStudentId: skip ? null : studentId },
    });

    await logAudit(session, 'Manual attendance match resolved', { rowId, studentId, skip });

    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}
