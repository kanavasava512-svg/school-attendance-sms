import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireSession, AuthError } from '@/lib/auth';
import { getClass } from '@/lib/classes';

export async function GET(req: NextRequest, { params }: { params: { classId: string } }) {
  try {
    await requireSession();
    const classDef = getClass(params.classId);
    if (!classDef) return NextResponse.json({ error: 'Unknown class' }, { status: 404 });

    const { searchParams } = new URL(req.url);
    const dateParam = searchParams.get('date');

    let attendanceDate: Date | null = null;
    if (dateParam) {
      attendanceDate = new Date(`${dateParam}T00:00:00.000Z`);
    } else {
      const latest = await prisma.attendanceRecord.findFirst({
        where: { className: classDef.slug },
        orderBy: { attendanceDate: 'desc' },
      });
      attendanceDate = latest?.attendanceDate ?? null;
    }

    const totalStudents = await prisma.student.count({ where: { className: classDef.slug, active: true } });

    if (!attendanceDate) {
      return NextResponse.json({
        classSlug: classDef.slug,
        classLabel: classDef.labelGujarati,
        attendanceDate: null,
        totalStudents,
        present: 0,
        absent: 0,
        records: [],
        unmatched: [],
      });
    }

    const records = await prisma.attendanceRecord.findMany({
      where: { className: classDef.slug, attendanceDate },
      include: { student: true },
      orderBy: { student: { studentName: 'asc' } },
    });

    const unmatched = await prisma.unmatchedAttendanceRow.findMany({
      where: { className: classDef.slug, attendanceDate, resolved: false },
    });

    // SMS status per student for this date, so the class table can show it inline.
    const smsLogs = await prisma.smsLog.findMany({
      where: { className: classDef.slug, attendanceDate, smsType: 'ATTENDANCE' },
    });
    const smsByStudent = new Map(smsLogs.map((l) => [l.studentId, l.status]));

    const present = records.filter((r) => r.status === 'PRESENT').length;
    const absent = records.filter((r) => r.status === 'ABSENT').length;

    return NextResponse.json({
      classSlug: classDef.slug,
      classLabel: classDef.labelGujarati,
      attendanceDate: attendanceDate.toISOString().slice(0, 10),
      totalStudents,
      present,
      absent,
      records: records.map((r) => ({
        id: r.id,
        studentId: r.studentId,
        childUid: r.student.childUid,
        studentName: r.student.studentName,
        studentNameGujarati: r.student.studentNameGujarati,
        section: r.student.section,
        status: r.status,
        mobileNumber: r.student.mobileNumber,
        smsStatus: smsByStudent.get(r.studentId) ?? null,
      })),
      unmatched,
    });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}
