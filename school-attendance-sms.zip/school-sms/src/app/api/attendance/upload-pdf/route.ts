import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requirePrincipal, AuthError } from '@/lib/auth';
import { parseAttendancePdf } from '@/lib/pdfParser';
import { getClass } from '@/lib/classes';
import { saveAttendancePdf } from '@/lib/storage';
import { logAudit } from '@/lib/audit';

const MAX_FILE_SIZE = 15 * 1024 * 1024;

function normName(s: string): string {
  return s.trim().toLowerCase().replace(/\s+/g, ' ');
}

export async function POST(req: NextRequest) {
  try {
    const session = await requirePrincipal();
    const formData = await req.formData();

    const file = formData.get('file');
    const classSlug = String(formData.get('classSlug') || '');
    const dateOverride = formData.get('dateOverride') ? String(formData.get('dateOverride')) : null;
    const confirmReplace = String(formData.get('confirmReplace') || '') === 'true';

    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'PDF ફાઈલ પસંદ કરો.' }, { status: 400 });
    }
    if (!/\.pdf$/i.test(file.name)) {
      return NextResponse.json({ error: 'ફક્ત .pdf ફાઈલ સ્વીકાર્ય છે.' }, { status: 400 });
    }
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json({ error: 'ફાઈલનું કદ ખૂબ મોટું છે (મહત્તમ 15MB).' }, { status: 400 });
    }
    const classDef = getClass(classSlug);
    if (!classDef) {
      return NextResponse.json({ error: 'ધોરણ પસંદ કરો.' }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const parsed = await parseAttendancePdf(buffer);

    if (parsed.extractionMode === 'ocr_unavailable') {
      return NextResponse.json(
        {
          error: 'Manual Verification Required',
          detail:
            'આ PDF સ્કેન કરેલી ઈમેજ જણાય છે. ટેક્સ્ટ કાઢી શકાયું નથી (OCR હજુ ગોઠવેલ નથી). કૃપા કરીને ટેક્સ્ટ-આધારિત PDF અપલોડ કરો અથવા હાજરી જાતે દાખલ કરો.',
        },
        { status: 422 }
      );
    }

    if (parsed.rows.length === 0) {
      return NextResponse.json(
        { error: 'Manual Verification Required', detail: 'PDF માંથી કોઈ હાજરી રેકોર્ડ મળ્યા નથી.' },
        { status: 422 }
      );
    }

    const attendanceDateStr = dateOverride || parsed.attendanceDate;
    if (!attendanceDateStr) {
      return NextResponse.json(
        { error: 'DATE_REQUIRED', detail: 'તારીખ શોધી શકાઈ નથી. કૃપા કરીને તારીખ પસંદ કરો.' },
        { status: 422 }
      );
    }
    const attendanceDate = new Date(`${attendanceDateStr}T00:00:00.000Z`);

    // Duplicate-date protection (spec section 48)
    const existingCount = await prisma.attendanceRecord.count({
      where: { className: classDef.slug, attendanceDate },
    });
    if (existingCount > 0 && !confirmReplace) {
      return NextResponse.json(
        {
          error: 'DUPLICATE_DATE',
          detail: 'આ તારીખની હાજરી પહેલેથી અપલોડ થયેલી છે.',
          existingCount,
        },
        { status: 409 }
      );
    }

    const students = await prisma.student.findMany({ where: { className: classDef.slug, active: true } });
    const byUid = new Map(students.map((s) => [s.childUid, s]));
    const byName = new Map(students.map((s) => [normName(s.studentName), s]));

    let matchedByUid = 0;
    let matchedByName = 0;
    let unmatched = 0;
    let presentCount = 0;
    let absentCount = 0;
    const needsResend: { studentName: string; childUid: string }[] = [];

    // Clear any stale unresolved rows from a previous attempt at this class/date
    await prisma.unmatchedAttendanceRow.deleteMany({
      where: { className: classDef.slug, attendanceDate, resolved: false },
    });

    const sourcePdfRef = await saveAttendancePdf(file.name, buffer);

    for (const row of parsed.rows) {
      if (row.status === 'PRESENT') presentCount++;
      if (row.status === 'ABSENT') absentCount++;

      let student = row.childUid ? byUid.get(row.childUid) : undefined;
      let matchType: 'CHILD_UID' | 'NAME_CLASS_SECTION' | null = student ? 'CHILD_UID' : null;

      if (student) matchedByUid++;

      if (!student) {
        const candidate = byName.get(normName(row.studentName));
        if (candidate) {
          student = candidate;
          matchType = 'NAME_CLASS_SECTION';
          matchedByName++;
        }
      }

      if (!student || row.status === 'UNKNOWN') {
        unmatched++;
        await prisma.unmatchedAttendanceRow.create({
          data: {
            className: classDef.slug,
            attendanceDate,
            rawChildUid: row.childUid,
            rawName: row.studentName,
            rawSection: row.section,
            rawStatus: row.rawStatus,
            sourcePdf: sourcePdfRef,
          },
        });
        continue;
      }

      if (row.status === 'ABSENT') {
        const alreadySent = await prisma.smsLog.findFirst({
          where: {
            studentId: student.id,
            attendanceDate,
            smsType: 'ATTENDANCE',
            status: { in: ['SENT', 'MOCK_SENT'] },
          },
        });
        const priorRecord = await prisma.attendanceRecord.findUnique({
          where: { studentId_attendanceDate: { studentId: student.id, attendanceDate } },
        });
        if (alreadySent && priorRecord && priorRecord.status === 'PRESENT') {
          needsResend.push({ studentName: student.studentName, childUid: student.childUid });
        }
      }

      await prisma.attendanceRecord.upsert({
        where: { studentId_attendanceDate: { studentId: student.id, attendanceDate } },
        update: { status: row.status as 'PRESENT' | 'ABSENT', sourcePdf: sourcePdfRef, matchType: matchType! },
        create: {
          studentId: student.id,
          className: classDef.slug,
          attendanceDate,
          status: row.status as 'PRESENT' | 'ABSENT',
          sourcePdf: sourcePdfRef,
          matchType: matchType!,
        },
      });
    }

    await logAudit(session, 'PDF Upload', {
      className: classDef.slug,
      attendanceDate: attendanceDateStr,
      matchedByUid,
      matchedByName,
      unmatched,
    });

    return NextResponse.json({
      ok: true,
      classSlug: classDef.slug,
      classLabel: classDef.labelGujarati,
      attendanceDate: attendanceDateStr,
      totalRows: parsed.rows.length,
      matchedByUid,
      matchedByName,
      unmatched,
      presentCount,
      absentCount,
      needsResend,
    });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    // eslint-disable-next-line no-console
    console.error(err);
    return NextResponse.json({ error: 'PDF પ્રોસેસ કરવામાં ભૂલ આવી.' }, { status: 500 });
  }
}
