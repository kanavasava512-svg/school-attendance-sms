import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireSession, AuthError } from '@/lib/auth';

export async function GET() {
  try {
    await requireSession();
    const logs = await prisma.importLog.findMany({ orderBy: { createdAt: 'desc' }, take: 25 });
    return NextResponse.json({ logs });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}
