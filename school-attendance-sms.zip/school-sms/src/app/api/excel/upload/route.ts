import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requirePrincipal, AuthError } from '@/lib/auth';
import { parseStudentWorkbook } from '@/lib/excelParser';
import { logAudit } from '@/lib/audit';

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB

export async function POST(req: NextRequest) {
  try {
    const session = await requirePrincipal();

    const formData = await req.formData();
    const file = formData.get('file');
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'Excel ફાઈલ પસંદ કરો.' }, { status: 400 });
    }
    if (!/\.(xlsx|xls)$/i.test(file.name)) {
      return NextResponse.json({ error: 'ફક્ત .xlsx અથવા .xls ફાઈલ સ્વીકાર્ય છે.' }, { status: 400 });
    }
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json({ error: 'ફાઈલનું કદ ખૂબ મોટું છે (મહત્તમ 10MB).' }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const parsed = parseStudentWorkbook(buffer);

    let totalRecords = 0;
    let newStudents = 0;
    let updatedStudents = 0;
    let mobileNumbersUpdated = 0;
    let missingMobile = 0;
    let invalidMobile = 0;
    let duplicateChildUid = 0;

    const seenUidsThisImport = new Set<string>();
    const rowErrors: Array<{ sheet: string; row: number; error: string }> = [];
    const perClass: Record<string, { total: number; new: number; updated: number }> = {};

    for (const cls of parsed.classes) {
      perClass[cls.classSlug!] = { total: 0, new: 0, updated: 0 };

      for (const row of cls.rows) {
        if (row.error) {
          rowErrors.push({ sheet: cls.sheetName, row: row.rowNumber, error: row.error });
          continue;
        }

        const uid = row.childUid!;
        if (seenUidsThisImport.has(uid)) {
          duplicateChildUid++;
          rowErrors.push({ sheet: cls.sheetName, row: row.rowNumber, error: `Duplicate Child UID: ${uid}` });
          continue;
        }
        seenUidsThisImport.add(uid);

        totalRecords++;
        perClass[cls.classSlug!].total++;

        if (row.mobileStatus === 'missing') missingMobile++;
        if (row.mobileStatus === 'invalid') invalidMobile++;

        const existing = await prisma.student.findUnique({ where: { childUid: uid } });

        if (existing) {
          const mobileChanged = existing.mobileNumber !== row.mobileNormalized;
          await prisma.student.update({
            where: { childUid: uid },
            data: {
              studentName: row.studentName!,
              studentNameGujarati: row.studentNameGujarati,
              className: cls.classSlug!,
              section: row.section,
              mobileNumber: row.mobileNormalized,
              mobileRaw: row.mobileRaw,
              active: true,
            },
          });
          updatedStudents++;
          perClass[cls.classSlug!].updated++;
          if (mobileChanged) mobileNumbersUpdated++;
        } else {
          await prisma.student.create({
            data: {
              childUid: uid,
              studentName: row.studentName!,
              studentNameGujarati: row.studentNameGujarati,
              className: cls.classSlug!,
              section: row.section,
              mobileNumber: row.mobileNormalized,
              mobileRaw: row.mobileRaw,
            },
          });
          newStudents++;
          perClass[cls.classSlug!].new++;
        }
      }
    }

    const unknownClassRows = parsed.unknownSheets.length;

    const importLog = await prisma.importLog.create({
      data: {
        fileName: file.name,
        uploadedBy: session.sub,
        className: 'ALL',
        totalRecords,
        newStudents,
        updatedStudents,
        mobileNumbersUpdated,
        missingMobile,
        invalidMobile,
        duplicateChildUid,
        unknownClassRows,
        errors: { rowErrors, unknownSheets: parsed.unknownSheets, perClass } as any,
      },
    });

    await logAudit(session, 'Excel Upload', { importLogId: importLog.id, fileName: file.name });

    return NextResponse.json({
      ok: true,
      summary: {
        totalRecords,
        newStudents,
        updatedStudents,
        mobileNumbersUpdated,
        missingMobile,
        invalidMobile,
        duplicateChildUid,
        unknownClassRows,
        unknownSheets: parsed.unknownSheets,
        perClass,
        rowErrors,
      },
    });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    // eslint-disable-next-line no-console
    console.error(err);
    return NextResponse.json({ error: 'Excel પ્રોસેસ કરવામાં ભૂલ આવી.' }, { status: 500 });
  }
}
