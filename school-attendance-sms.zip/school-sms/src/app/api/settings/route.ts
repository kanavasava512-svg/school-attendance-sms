import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireSession, requirePrincipal, AuthError } from '@/lib/auth';
import { logAudit } from '@/lib/audit';

async function getOrCreateSchool() {
  let school = await prisma.school.findFirst();
  if (!school) school = await prisma.school.create({ data: {} });
  return school;
}

export async function GET() {
  try {
    await requireSession();
    const school = await getOrCreateSchool();
    return NextResponse.json({ school, mockSmsMode: (process.env.MOCK_SMS ?? 'true').toLowerCase() !== 'false' });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}

export async function PUT(req: NextRequest) {
  try {
    const session = await requirePrincipal();
    const body = await req.json().catch(() => ({}));
    const school = await getOrCreateSchool();

    const updated = await prisma.school.update({
      where: { id: school.id },
      data: {
        smsTemplate: typeof body.smsTemplate === 'string' ? body.smsTemplate : school.smsTemplate,
        logoUrl: typeof body.logoUrl === 'string' ? body.logoUrl : school.logoUrl,
      },
    });

    await logAudit(session, 'Settings Changed', { fields: Object.keys(body) });

    return NextResponse.json({ ok: true, school: updated });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}
