import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireSession, AuthError } from '@/lib/auth';
import { CLASSES } from '@/lib/classes';

export async function GET(req: Request) {
  try {
    await requireSession();

    const { searchParams } = new URL(req.url);
    const dateParam = searchParams.get('date');
    const selectedDate = dateParam || new Date().toISOString().slice(0, 10);
    const attendanceDate = new Date(`${selectedDate}T00:00:00.000Z`);

    const cards = await Promise.all(
      CLASSES.map(async (c) => {
        const totalStudents = await prisma.student.count({ where: { className: c.slug, active: true } });
        const latest = await prisma.attendanceRecord.findFirst({
          where: { className: c.slug, attendanceDate },
        });

        let present = 0;
        let absent = 0;
        let smsSent = 0;
        let smsFailed = 0;
        let attendanceDate: string | null = null;

        if (latest) {
          attendanceDate = latest.attendanceDate.toISOString().slice(0, 10);
          present = await prisma.attendanceRecord.count({
            where: { className: c.slug, attendanceDate: latest.attendanceDate, status: 'PRESENT' },
          });
          absent = await prisma.attendanceRecord.count({
            where: { className: c.slug, attendanceDate: latest.attendanceDate, status: 'ABSENT' },
          });
          smsSent = await prisma.smsLog.count({
            where: {
              className: c.slug,
              attendanceDate: latest.attendanceDate,
              smsType: 'ATTENDANCE',
              status: { in: ['SENT', 'MOCK_SENT'] },
            },
          });
          smsFailed = await prisma.smsLog.count({
            where: {
              className: c.slug,
              attendanceDate: latest.attendanceDate,
              smsType: 'ATTENDANCE',
              status: 'FAILED',
            },
          });
        }

        return {
          slug: c.slug,
          labelGujarati: c.labelGujarati,
          labelEnglish: c.labelEnglish,
          totalStudents,
          attendanceDate,
          present,
          absent,
          smsSent,
          smsFailed,
          attendanceUploaded: !!latest,
        };
      })
    );

    const totals = cards.reduce(
      (acc, c) => {
        acc.totalStudents += c.totalStudents;
        acc.present += c.present;
        acc.absent += c.absent;
        acc.smsSent += c.smsSent;
        acc.smsFailed += c.smsFailed;
        if (c.attendanceUploaded) acc.classesUploaded += 1;
        else acc.classesPending += 1;
        return acc;
      },
      { totalStudents: 0, present: 0, absent: 0, smsSent: 0, smsFailed: 0, classesUploaded: 0, classesPending: 0 }
    );

    return NextResponse.json({ cards, totals, today: new Date().toISOString().slice(0, 10), selectedDate });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}
