import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requirePrincipal, AuthError } from '@/lib/auth';
import { normalizeMobile } from '@/lib/mobile';
import { hashSecret } from '@/lib/hash';
import { logAudit } from '@/lib/audit';

export async function GET() {
  try {
    await requirePrincipal();
    const teachers = await prisma.teacher.findMany({
      select: { id: true, name: true, mobile: true, active: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json({ teachers });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await requirePrincipal();
    const body = await req.json().catch(() => ({}));
    const name = String(body.name || '').trim();
    const password = String(body.password || '');
    const check = normalizeMobile(body.mobile);

    if (!name || check.kind !== 'valid' || password.length < 4) {
      return NextResponse.json(
        { error: 'નામ, માન્ય મોબાઈલ નંબર અને ઓછામાં ઓછા 4 અક્ષરનો પાસવર્ડ જરૂરી છે.' },
        { status: 400 }
      );
    }

    const teacher = await prisma.teacher.create({
      data: { name, mobile: check.normalized, passwordHash: hashSecret(password) },
    });

    await logAudit(session, 'Teacher account created', { teacherId: teacher.id, mobile: check.normalized });

    return NextResponse.json({ ok: true, teacher: { id: teacher.id, name: teacher.name, mobile: teacher.mobile } });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    if ((err as { code?: string })?.code === 'P2002') {
      return NextResponse.json({ error: 'આ મોબાઈલ નંબર પહેલેથી નોંધાયેલ છે.' }, { status: 409 });
    }
    throw err;
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const session = await requirePrincipal();
    const body = await req.json().catch(() => ({}));
    const id = String(body.id || '');
    if (!id) return NextResponse.json({ error: 'Teacher id required' }, { status: 400 });

    const teacher = await prisma.teacher.update({
      where: { id },
      data: { active: Boolean(body.active) },
    });

    await logAudit(session, 'Teacher account updated', { teacherId: id, active: teacher.active });
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}
