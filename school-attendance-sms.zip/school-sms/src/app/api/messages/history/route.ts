import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireSession, AuthError } from '@/lib/auth';

export async function GET() {
  try {
    await requireSession();
    const messages = await prisma.generalMessage.findMany({
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
    return NextResponse.json({ messages });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}
