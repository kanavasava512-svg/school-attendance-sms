import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireSession, AuthError } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    await requireSession();
    const { searchParams } = new URL(req.url);
    const q = searchParams.get('q')?.trim();
    const className = searchParams.get('className')?.trim();

    const students = await prisma.student.findMany({
      where: {
        active: true,
        ...(className ? { className } : {}),
        ...(q
          ? {
              OR: [
                { studentName: { contains: q, mode: 'insensitive' } },
                { studentNameGujarati: { contains: q, mode: 'insensitive' } },
                { childUid: { contains: q } },
                { mobileNumber: { contains: q } },
              ],
            }
          : {}),
      },
      orderBy: [{ className: 'asc' }, { studentName: 'asc' }],
      take: 500,
    });

    return NextResponse.json({ students });
  } catch (err) {
    if (err instanceof AuthError) return NextResponse.json({ error: err.message }, { status: err.status });
    throw err;
  }
}
