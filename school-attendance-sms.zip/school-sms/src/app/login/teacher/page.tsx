'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { apiPost } from '@/lib/clientFetch';

export default function TeacherLoginPage() {
  const router = useRouter();
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function login(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await apiPost('/api/auth/teacher', { mobile, password });
      router.push('/dashboard');
      router.refresh();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-6">
          <img src="/logo.png" alt="School Logo" className="w-20 h-20 mx-auto mb-3" />
          <h1 className="text-xl font-semibold">શ્રી નાના દિનારા-1 પ્રાથમિક શાળા</h1>
          <p className="text-gray-500 text-sm mt-1">શિક્ષક લોગિન (ફક્ત જોવા માટે)</p>
        </div>

        <div className="card">
          <form onSubmit={login} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">મોબાઈલ નંબર</label>
              <input className="input" value={mobile} onChange={(e) => setMobile(e.target.value)} required />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">પાસવર્ડ</label>
              <input
                className="input"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            {error && <p className="text-sm text-red-600">{error}</p>}
            <button className="btn-primary w-full" disabled={loading} type="submit">
              {loading ? 'પ્રવેશ કરી રહ્યા છીએ...' : 'પ્રવેશ કરો'}
            </button>
          </form>
        </div>

        <p className="text-center text-sm text-gray-500 mt-4">
          આચાર્ય છો? <a className="text-brand-600 font-medium" href="/login/principal">Principal Login</a>
        </p>
      </div>
    </div>
  );
}
