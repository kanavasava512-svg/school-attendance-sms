'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { apiPost } from '@/lib/clientFetch';

export default function PrincipalLoginPage() {
  const router = useRouter();
  const [step, setStep] = useState<'mobile' | 'otp'>('mobile');
  const [mobile, setMobile] = useState('');
  const [code, setCode] = useState('');
  const [devOtp, setDevOtp] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function requestOtp(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await apiPost<{ devOtp?: string }>('/api/auth/principal/request-otp', { mobile });
      setDevOtp(res.devOtp ?? null);
      setStep('otp');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function verifyOtp(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await apiPost('/api/auth/principal/verify-otp', { mobile, code });
      router.push('/dashboard');
      router.refresh();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-6">
          <img src="/logo.png" alt="School Logo" className="w-20 h-20 mx-auto mb-3" />
          <h1 className="text-xl font-semibold">શ્રી નાના દિનારા-1 પ્રાથમિક શાળા</h1>
          <p className="text-gray-500 text-sm mt-1">આચાર્ય લોગિન</p>
        </div>

        <div className="card">
          {step === 'mobile' ? (
            <form onSubmit={requestOtp} className="space-y-4">
              <label className="block text-sm font-medium text-gray-700">મોબાઈલ નંબર</label>
              <input
                className="input"
                inputMode="numeric"
                placeholder="9876543210"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                required
              />
              {error && <p className="text-sm text-red-600">{error}</p>}
              <button className="btn-primary w-full" disabled={loading} type="submit">
                {loading ? 'મોકલી રહ્યા છીએ...' : 'OTP મેળવો'}
              </button>
            </form>
          ) : (
            <form onSubmit={verifyOtp} className="space-y-4">
              <label className="block text-sm font-medium text-gray-700">OTP દાખલ કરો</label>
              <input
                className="input tracking-widest text-center text-lg"
                inputMode="numeric"
                maxLength={6}
                placeholder="••••••"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                required
              />
              {devOtp && (
                <p className="text-xs text-gray-500">
                  Demo/Dev Mode OTP: <span className="font-mono font-semibold">{devOtp}</span>
                </p>
              )}
              {error && <p className="text-sm text-red-600">{error}</p>}
              <button className="btn-primary w-full" disabled={loading} type="submit">
                {loading ? 'ચકાસી રહ્યા છીએ...' : 'પ્રવેશ કરો'}
              </button>
              <button
                type="button"
                className="text-sm text-gray-500 w-full text-center"
                onClick={() => setStep('mobile')}
              >
                ← મોબાઈલ નંબર બદલો
              </button>
            </form>
          )}
        </div>

        <p className="text-center text-sm text-gray-500 mt-4">
          શિક્ષક છો? <a className="text-brand-600 font-medium" href="/login/teacher">Teacher Login</a>
        </p>
      </div>
    </div>
  );
}
