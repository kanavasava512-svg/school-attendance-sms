import type { Metadata } from 'next';
import { Noto_Sans_Gujarati } from 'next/font/google';
import './globals.css';
import PwaRegister from './PwaRegister';

const notoGujarati = Noto_Sans_Gujarati({
  subsets: ['gujarati', 'latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-gujarati',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'શ્રી નાના દિનારા-1 પ્રાથમિક શાળા — હાજરી SMS',
  description: 'School Attendance & Parent SMS Application',
  manifest: '/manifest.webmanifest',
  icons: {
    icon: '/icon-192.png',
    apple: '/icon-192.png',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="gu">
      <body className={`${notoGujarati.variable} font-gujarati bg-gray-50 text-gray-900 antialiased`}>
        <PwaRegister />
        {children}
      </body>
    </html>
  );
}
