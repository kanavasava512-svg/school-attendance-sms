import type { Metadata } from 'next';
import { Noto_Sans_Gujarati } from 'next/font/google';
import './globals.css';

const notoGujarati = Noto_Sans_Gujarati({
  subsets: ['gujarati', 'latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-gujarati',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'શ્રી નાના દિનારા-1 પ્રાથમિક શાળા — હાજરી SMS',
  description: 'School Attendance & Parent SMS Application',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="gu">
      <body className={`${notoGujarati.variable} font-gujarati bg-gray-50 text-gray-900 antialiased`}>
        {children}
      </body>
    </html>
  );
}
