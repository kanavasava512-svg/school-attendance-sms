'use client';

import { useEffect, useState } from 'react';
import { apiGet } from '@/lib/clientFetch';
import { CLASSES } from '@/lib/classes';

export default function StudentsPage() {
  const [students, setStudents] = useState<any[]>([]);
  const [q, setQ] = useState('');
  const [className, setClassName] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const params = new URLSearchParams();
    if (q) params.set('q', q);
    if (className) params.set('className', className);
    setLoading(true);
    apiGet(`/api/students?${params.toString()}`)
      .then((d) => setStudents(d.students || []))
      .finally(() => setLoading(false));
  }, [q, className]);

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">વિદ્યાર્થીઓ</h1>

      <div className="card grid sm:grid-cols-2 gap-3">
        <input
          className="input"
          placeholder="નામ / Child UID / મોબાઈલ શોધો"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <select className="input" value={className} onChange={(e) => setClassName(e.target.value)}>
          <option value="">બધા ધોરણ</option>
          {CLASSES.map((c) => (
            <option key={c.slug} value={c.slug}>
              {c.labelGujarati}
            </option>
          ))}
        </select>
      </div>

      <div className="card overflow-x-auto">
        {loading ? (
          <p className="text-sm text-gray-500">લોડ થઈ રહ્યું છે...</p>
        ) : students.length === 0 ? (
          <p className="text-sm text-gray-500">કોઈ વિદ્યાર્થી મળ્યા નથી.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-gray-500 border-b border-gray-100">
                <th className="py-2 pr-3">Child UID</th>
                <th className="py-2 pr-3">નામ</th>
                <th className="py-2 pr-3">ગુજરાતી નામ</th>
                <th className="py-2 pr-3">ધોરણ</th>
                <th className="py-2 pr-3">Section</th>
                <th className="py-2 pr-3">Mobile</th>
              </tr>
            </thead>
            <tbody>
              {students.map((s) => (
                <tr key={s.id} className="border-b border-gray-50 last:border-0">
                  <td className="py-2 pr-3 font-mono text-xs">{s.childUid}</td>
                  <td className="py-2 pr-3">{s.studentName}</td>
                  <td className="py-2 pr-3">{s.studentNameGujarati || '—'}</td>
                  <td className="py-2 pr-3">{s.className}</td>
                  <td className="py-2 pr-3">{s.section || '—'}</td>
                  <td className="py-2 pr-3">
                    {s.mobileNumber ? s.mobileNumber.replace('+91', '') : <span className="text-red-600 text-xs">ખૂટે છે</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
