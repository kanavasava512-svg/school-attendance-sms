'use client';

import { useEffect, useRef, useState } from 'react';
import { toast } from '@/components/Toast';

export default function ExcelPage() {
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [summary, setSummary] = useState<any>(null);
  const [logs, setLogs] = useState<any[]>([]);

  useEffect(() => {
    fetch('/api/excel/import-logs')
      .then((r) => r.json())
      .then((d) => setLogs(d.logs || []));
  }, [summary]);

  async function upload(e: React.FormEvent) {
    e.preventDefault();
    const file = fileRef.current?.files?.[0];
    if (!file) return;

    setUploading(true);
    setSummary(null);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await fetch('/api/excel/upload', { method: 'POST', body: fd });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error || 'Excel અપલોડ નિષ્ફળ', 'error');
        return;
      }
      setSummary(data.summary);
      toast('Excel અપલોડ થયું', 'success');
    } catch {
      toast('Excel અપલોડ નિષ્ફળ', 'error');
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-xl font-semibold">Excel અપલોડ / બદલો</h1>
        <p className="text-sm text-gray-500 mt-1">
          વિદ્યાર્થીઓ અને વાલીઓના મોબાઈલ નંબર ધરાવતી Excel ફાઈલ અપલોડ કરો. Child UID અનુસાર જૂનો ડેટા અપડેટ થશે; જૂનો SMS ઇતિહાસ યથાવત રહેશે.
        </p>
      </div>

      <form onSubmit={upload} className="card space-y-4">
        <input ref={fileRef} type="file" accept=".xlsx,.xls" className="input" required />
        <button className="btn-primary w-full" disabled={uploading} type="submit">
          {uploading ? 'પ્રોસેસ થઈ રહ્યું છે...' : 'Excel અપલોડ કરો'}
        </button>
        <a href="/help/excel-format" className="text-sm text-brand-600 block text-center">
          Excel ફોર્મેટ જુઓ
        </a>
      </form>

      {summary && (
        <div className="card space-y-3">
          <h2 className="font-semibold">Excel Import Summary</h2>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <Stat label="કુલ વિદ્યાર્થીઓ" value={summary.totalRecords} />
            <Stat label="નવા વિદ્યાર્થીઓ" value={summary.newStudents} />
            <Stat label="Updated Students" value={summary.updatedStudents} />
            <Stat label="Mobile Numbers Updated" value={summary.mobileNumbersUpdated} />
            <Stat label="Missing Mobile Numbers" value={summary.missingMobile} warn />
            <Stat label="Invalid Mobile Numbers" value={summary.invalidMobile} warn />
            <Stat label="Duplicate Child UID" value={summary.duplicateChildUid} warn />
            <Stat label="Unknown Class Sheets" value={summary.unknownClassRows} warn />
          </div>
          {summary.unknownSheets?.length > 0 && (
            <p className="text-sm text-amber-700">
              ઓળખાયેલ નથી તેવી શીટ્સ: {summary.unknownSheets.join(', ')}
            </p>
          )}
          {summary.rowErrors?.length > 0 && (
            <details className="text-sm">
              <summary className="cursor-pointer text-amber-700">{summary.rowErrors.length} ભૂલો જુઓ</summary>
              <ul className="mt-2 space-y-1 max-h-48 overflow-y-auto">
                {summary.rowErrors.map((e: any, i: number) => (
                  <li key={i} className="text-gray-600">
                    {e.sheet} · Row {e.row}: {e.error}
                  </li>
                ))}
              </ul>
            </details>
          )}
        </div>
      )}

      <div className="card">
        <h2 className="font-semibold mb-3">પાછલા Import</h2>
        {logs.length === 0 ? (
          <p className="text-sm text-gray-500">હજુ સુધી કોઈ Excel અપલોડ કરવામાં આવ્યું નથી.</p>
        ) : (
          <div className="space-y-2">
            {logs.map((l) => (
              <div key={l.id} className="text-sm border-b border-gray-100 pb-2 last:border-0">
                <p className="font-medium">{l.fileName}</p>
                <p className="text-gray-500">
                  {new Date(l.createdAt).toLocaleString('en-IN')} · કુલ {l.totalRecords} · નવા {l.newStudents} ·
                  અપડેટ {l.updatedStudents}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value, warn }: { label: string; value: number; warn?: boolean }) {
  return (
    <div className={`rounded-lg p-3 ${warn && value > 0 ? 'bg-amber-50' : 'bg-gray-50'}`}>
      <p className="text-gray-500 text-xs">{label}</p>
      <p className={`text-lg font-semibold ${warn && value > 0 ? 'text-amber-700' : ''}`}>{value}</p>
    </div>
  );
}
