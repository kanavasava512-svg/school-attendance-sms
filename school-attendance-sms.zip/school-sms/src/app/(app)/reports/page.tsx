'use client';

import { useEffect, useState } from 'react';
import { apiGet } from '@/lib/clientFetch';
import { CLASSES } from '@/lib/classes';
import StatusBadge from '@/components/StatusBadge';

export default function ReportsPage() {
  const [classSlug, setClassSlug] = useState(CLASSES[0].slug);
  const [date, setDate] = useState('');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    const q = date ? `?date=${date}` : '';
    apiGet(`/api/attendance/${classSlug}${q}`)
      .then(setData)
      .finally(() => setLoading(false));
  }, [classSlug, date]);

  function exportCsv() {
    if (!data?.records?.length) return;
    const header = 'Child UID,Student Name,Gujarati Name,Section,Status,Mobile\n';
    const rows = data.records
      .map((r: any) =>
        [r.childUid, r.studentName, r.studentNameGujarati || '', r.section || '', r.status, r.mobileNumber || '']
          .map((v: string) => `"${String(v).replace(/"/g, '""')}"`)
          .join(',')
      )
      .join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `attendance-${classSlug}-${data.attendanceDate}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Reports — Daily / Class-wise Attendance</h1>

      <div className="card grid sm:grid-cols-3 gap-3">
        <select className="input" value={classSlug} onChange={(e) => setClassSlug(e.target.value)}>
          {CLASSES.map((c) => (
            <option key={c.slug} value={c.slug}>
              {c.labelGujarati}
            </option>
          ))}
        </select>
        <input type="date" className="input" value={date} onChange={(e) => setDate(e.target.value)} />
        <button className="btn-secondary" onClick={exportCsv} disabled={!data?.records?.length}>
          Export CSV
        </button>
      </div>

      <div className="card overflow-x-auto">
        {loading ? (
          <p className="text-sm text-gray-500">લોડ થઈ રહ્યું છે...</p>
        ) : !data?.attendanceDate ? (
          <p className="text-sm text-gray-500">આ ધોરણની હાજરી અપલોડ કરવામાં આવી નથી.</p>
        ) : (
          <>
            <p className="text-sm text-gray-500 mb-3">
              તારીખ: {data.attendanceDate} · કુલ {data.totalStudents} · હાજર {data.present} · ગેરહાજર {data.absent}
            </p>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-500 border-b border-gray-100">
                  <th className="py-2 pr-3">Child UID</th>
                  <th className="py-2 pr-3">નામ</th>
                  <th className="py-2 pr-3">Status</th>
                  <th className="py-2 pr-3">SMS</th>
                </tr>
              </thead>
              <tbody>
                {data.records.map((r: any) => (
                  <tr key={r.id} className="border-b border-gray-50 last:border-0">
                    <td className="py-2 pr-3 font-mono text-xs">{r.childUid}</td>
                    <td className="py-2 pr-3">{r.studentName}</td>
                    <td className="py-2 pr-3">
                      <StatusBadge status={r.status} />
                    </td>
                    <td className="py-2 pr-3">
                      <StatusBadge status={r.smsStatus} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}
      </div>
    </div>
  );
}
