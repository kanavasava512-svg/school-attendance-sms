'use client';

import { useEffect, useState } from 'react';
import { apiGet, apiPost, apiPutPatch } from '@/lib/clientFetch';
import { toast } from '@/components/Toast';

export default function SettingsPage() {
  const [school, setSchool] = useState<any>(null);
  const [template, setTemplate] = useState('');
  const [mockMode, setMockMode] = useState(true);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [newTeacher, setNewTeacher] = useState({ name: '', mobile: '', password: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    apiGet('/api/settings').then((d) => {
      setSchool(d.school);
      setTemplate(d.school.smsTemplate);
      setMockMode(d.mockSmsMode);
    });
    apiGet('/api/teachers')
      .then((d) => setTeachers(d.teachers || []))
      .catch(() => {});
  }, []);

  async function saveTemplate() {
    setSaving(true);
    try {
      await apiPutPatch('PUT', '/api/settings', { smsTemplate: template });
      toast('સેટિંગ્સ સાચવ્યા', 'success');
    } catch (e: any) {
      toast(e.message, 'error');
    } finally {
      setSaving(false);
    }
  }

  async function addTeacher(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiPost('/api/teachers', newTeacher);
      toast('શિક્ષક ઉમેરાયા', 'success');
      setNewTeacher({ name: '', mobile: '', password: '' });
      const d = await apiGet('/api/teachers');
      setTeachers(d.teachers || []);
    } catch (e: any) {
      toast(e.message, 'error');
    }
  }

  async function toggleTeacher(id: string, active: boolean) {
    await apiPutPatch('PATCH', '/api/teachers', { id, active });
    const d = await apiGet('/api/teachers');
    setTeachers(d.teachers || []);
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-xl font-semibold">સેટિંગ્સ</h1>

      <div className="card space-y-3">
        <h2 className="font-semibold">શાળાની માહિતી</h2>
        {school && (
          <div className="text-sm text-gray-600 space-y-1">
            <p>{school.nameGujarati}</p>
            <p>{school.nameEnglish}</p>
            <p>School Code: {school.schoolCode}</p>
          </div>
        )}
      </div>

      <div className="card space-y-3">
        <h2 className="font-semibold">Attendance SMS Template</h2>
        <p className="text-xs text-gray-500">
          Variables: {'{student_name_gujarati}'}, {'{student_name}'}, {'{date}'}, {'{class}'}, {'{school_name}'}
        </p>
        <textarea className="input min-h-[120px]" value={template} onChange={(e) => setTemplate(e.target.value)} />
        <button className="btn-primary" disabled={saving} onClick={saveTemplate}>
          સાચવો
        </button>
      </div>

      <div className="card space-y-2">
        <h2 className="font-semibold">SMS Mode</h2>
        <p className="text-sm">
          હાલ:{' '}
          <span className={`font-medium ${mockMode ? 'text-amber-700' : 'text-green-700'}`}>
            {mockMode ? 'MOCK SMS MODE (Demo — કોઈ Real SMS મોકલાશે નહીં)' : 'Real SMS Mode'}
          </span>
        </p>
        <p className="text-xs text-gray-500">
          MOCK_SMS environment variable દ્વારા બદલો. Real SMS Mode સક્રિય કરતા પહેલા ખાતરી કરો કે SMS provider ના
          environment variables ગોઠવેલા છે — વાસ્તવિક SMS ચાર્જ લાગુ થઈ શકે છે.
        </p>
      </div>

      <div className="card space-y-3">
        <h2 className="font-semibold">શિક્ષક એકાઉન્ટ (Viewer Only)</h2>
        <form onSubmit={addTeacher} className="grid sm:grid-cols-3 gap-2">
          <input
            className="input"
            placeholder="નામ"
            value={newTeacher.name}
            onChange={(e) => setNewTeacher({ ...newTeacher, name: e.target.value })}
            required
          />
          <input
            className="input"
            placeholder="મોબાઈલ"
            value={newTeacher.mobile}
            onChange={(e) => setNewTeacher({ ...newTeacher, mobile: e.target.value })}
            required
          />
          <input
            className="input"
            placeholder="પાસવર્ડ"
            type="password"
            value={newTeacher.password}
            onChange={(e) => setNewTeacher({ ...newTeacher, password: e.target.value })}
            required
          />
          <button className="btn-primary sm:col-span-3" type="submit">
            શિક્ષક ઉમેરો
          </button>
        </form>

        <div className="space-y-2 pt-2">
          {teachers.map((t) => (
            <div key={t.id} className="flex items-center justify-between text-sm border-b border-gray-100 pb-2">
              <div>
                <p className="font-medium">{t.name}</p>
                <p className="text-gray-500 text-xs">{t.mobile.replace('+91', '')}</p>
              </div>
              <button className="btn-secondary text-xs" onClick={() => toggleTeacher(t.id, !t.active)}>
                {t.active ? 'નિષ્ક્રિય કરો' : 'સક્રિય કરો'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
