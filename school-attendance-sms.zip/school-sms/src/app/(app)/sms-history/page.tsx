'use client';

import { useEffect, useState } from 'react';
import { apiGet } from '@/lib/clientFetch';
import StatusBadge from '@/components/StatusBadge';
import { CLASSES } from '@/lib/classes';

export default function SmsHistoryPage() {
  const [logs, setLogs] = useState<any[]>([]);
  const [className, setClassName] = useState('');
  const [smsType, setSmsType] = useState('');
  const [status, setStatus] = useState('');
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const params = new URLSearchParams();
    if (className) params.set('className', className);
    if (smsType) params.set('smsType', smsType);
    if (status) params.set('status', status);
    if (q) params.set('q', q);
    setLoading(true);
    apiGet(`/api/sms/history?${params.toString()}`)
      .then((d) => setLogs(d.logs || []))
      .finally(() => setLoading(false));
  }, [className, smsType, status, q]);

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">SMS ઇતિહાસ</h1>

      <div className="card grid sm:grid-cols-4 gap-3">
        <select className="input" value={className} onChange={(e) => setClassName(e.target.value)}>
          <option value="">બધા ધોરણ</option>
          {CLASSES.map((c) => (
            <option key={c.slug} value={c.slug}>
              {c.labelGujarati}
            </option>
          ))}
        </select>
        <select className="input" value={smsType} onChange={(e) => setSmsType(e.target.value)}>
          <option value="">બધા પ્રકાર</option>
          <option value="ATTENDANCE">Attendance SMS</option>
          <option value="GENERAL">General Parent Message</option>
        </select>
        <select className="input" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">બધા Status</option>
          <option value="SENT">Sent</option>
          <option value="MOCK_SENT">Mock Sent</option>
          <option value="FAILED">Failed</option>
        </select>
        <input className="input" placeholder="Search name/mobile/UID" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      <div className="card overflow-x-auto">
        {loading ? (
          <p className="text-sm text-gray-500">લોડ થઈ રહ્યું છે...</p>
        ) : logs.length === 0 ? (
          <p className="text-sm text-gray-500">હજુ સુધી કોઈ SMS મોકલવામાં આવ્યો નથી.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-gray-500 border-b border-gray-100">
                <th className="py-2 pr-3">તારીખ/સમય</th>
                <th className="py-2 pr-3">ધોરણ</th>
                <th className="py-2 pr-3">વિદ્યાર્થી</th>
                <th className="py-2 pr-3">Mobile</th>
                <th className="py-2 pr-3">Type</th>
                <th className="py-2 pr-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((l) => (
                <tr key={l.id} className="border-b border-gray-50 last:border-0 align-top">
                  <td className="py-2 pr-3 whitespace-nowrap">{new Date(l.createdAt).toLocaleString('en-IN')}</td>
                  <td className="py-2 pr-3">{l.className}</td>
                  <td className="py-2 pr-3">{l.studentName || '—'}</td>
                  <td className="py-2 pr-3">{l.mobileNumber}</td>
                  <td className="py-2 pr-3">{l.smsType === 'ATTENDANCE' ? 'હાજરી' : 'સામાન્ય'}</td>
                  <td className="py-2 pr-3">
                    <StatusBadge status={l.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
