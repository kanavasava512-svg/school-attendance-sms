export default function ExcelFormatHelpPage() {
  return (
    <div className="space-y-4 max-w-2xl">
      <h1 className="text-xl font-semibold">Excel Format</h1>
      <div className="card space-y-3 text-sm">
        <p>દરેક ધોરણ માટે અલગ Sheet હોવી જોઈએ (દા.ત. "class 7"). "Sheet1" ને અવગણવામાં આવે છે.</p>
        <table className="w-full border border-gray-200">
          <thead>
            <tr className="bg-gray-50 text-left">
              <th className="p-2 border-b border-gray-200">Column</th>
              <th className="p-2 border-b border-gray-200">વર્ણન</th>
            </tr>
          </thead>
          <tbody>
            {[
              ['Sr.No', 'ક્રમ (વૈકલ્પિક)'],
              ['Child UID', 'ફરજિયાત, અનન્ય (Primary Key)'],
              ['Student Name', 'વિદ્યાર્થીનું અંગ્રેજી નામ'],
              ['STUDENT NAME IN GUJARATI', 'SMS માટે વપરાય છે — ઉપલબ્ધ હોય તો પ્રાધાન્ય'],
              ['STD', 'ધોરણ'],
              ['Section', 'વિભાગ (A/B...)'],
              ['MOBILE NUMBER', 'વાલીનો મોબાઈલ નંબર — 10 અંક, +91 અથવા 91 સાથે પણ ચાલશે'],
            ].map(([k, v]) => (
              <tr key={k}>
                <td className="p-2 border-b border-gray-100 font-mono text-xs">{k}</td>
                <td className="p-2 border-b border-gray-100">{v}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="text-gray-500">
          Column નામોની જોડણી/અક્ષર-કેસ થોડી અલગ હોય તો પણ સિસ્ટમ આપોઆપ ઓળખી લે છે (દા.ત. "Sr.No" અથવા "Sr.NO").
        </p>
      </div>
    </div>
  );
}
