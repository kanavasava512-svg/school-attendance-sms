export default function PdfFormatHelpPage() {
  return (
    <div className="space-y-4 max-w-2xl">
      <h1 className="text-xl font-semibold">Attendance PDF Format</h1>
      <div className="card space-y-3 text-sm">
        <p>
          દરેક ધોરણ માટે અલગ Attendance PDF અપલોડ કરો. PDF માં નીચેની માહિતી હોવી જરૂરી છે:
        </p>
        <ul className="list-disc pl-5 space-y-1">
          <li>School Code</li>
          <li>
            <span className="font-mono text-xs">Attendance Report for Class: 7 | Date : 11-09-2026</span> જેવી લાઈન
          </li>
          <li>Table: Child UID, Student Name, Section, Status (Present / ABSENT)</li>
        </ul>
        <div className="bg-gray-50 rounded-lg p-3 font-mono text-xs overflow-x-auto">
          Child UID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Student Name&nbsp;&nbsp;&nbsp;&nbsp;Section&nbsp;&nbsp;Status
          <br />
          240105007022010021&nbsp;&nbsp;ABDEMAN K SAMA&nbsp;&nbsp;&nbsp;A&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ABSENT
        </div>
        <p className="text-gray-500">
          "Present" / "PRESENT" / "present" અને "ABSENT" / "Absent" / "absent" — બંને પ્રકારના લખાણને સિસ્ટમ
          આપોઆપ સરખા ગણે છે. જો PDF ઈમેજ સ્કેન હોય (ટેક્સ્ટ ન નીકળે), તો "Manual Verification Required" બતાવવામાં
          આવશે અને હાજરી જાતે દાખલ કરવી પડશે.
        </p>
      </div>
    </div>
  );
}
