'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { apiGet } from '@/lib/clientFetch';
import { toast } from '@/components/Toast';
import ConfirmModal from '@/components/ConfirmModal';
import { getClass } from '@/lib/classes';

export default function GeneralMessageClassPage() {
  const params = useParams<{ classId: string }>();
  const classDef = getClass(params.classId);

  const [message, setMessage] = useState('');
  const [counts, setCounts] = useState<any>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [history, setHistory] = useState<any[]>([]);
  const [freeSmsIndex, setFreeSmsIndex] = useState<number | null>(null);

  useEffect(() => {
    apiGet(`/api/sms/general/preview?classSlug=${params.classId}`).then(setCounts);
    apiGet('/api/messages/history').then((d) =>
      setHistory((d.messages || []).filter((m: any) => m.className === params.classId))
    );
  }, [params.classId]);

  function openFreeSmsAt(index: number) {
    const recipients = counts?.freeSmsRecipients || [];
    const recipient = recipients[index];
    if (!recipient || !message.trim()) return;
    setFreeSmsIndex(index);
    window.location.href = `sms:${recipient.mobile}?body=${encodeURIComponent(message.trim())}`;
  }

  function startFreeSmsQueue() {
    const recipients = counts?.freeSmsRecipients || [];
    if (!recipients.length || !message.trim()) return;
    openFreeSmsAt(0);
  }

  function openNextFreeSms() {
    const recipients = counts?.freeSmsRecipients || [];
    if (freeSmsIndex === null) return startFreeSmsQueue();
    const next = freeSmsIndex + 1;
    if (next >= recipients.length) {
      toast('બધા Free Mobile SMS તૈયાર થઈ ગયા. દરેક SMSમાં Send દબાવ્યું છે તેની ખાતરી કરો.', 'success');
      return;
    }
    openFreeSmsAt(next);
  }

  async function send() {
    setSending(true);
    try {
      const res = await fetch('/api/sms/general/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ classSlug: params.classId, message, confirmed: true }),
      });
      const result = await res.json();
      if (!res.ok) {
        toast(result.error || 'સંદેશ મોકલવામાં ભૂલ', 'error');
        return;
      }
      toast(
        `Message Sent — Successful: ${result.successful}, Failed: ${result.failed}, Skipped: ${result.skipped}${
          result.mock ? ' (Demo Mode)' : ''
        }`,
        'success'
      );
      setConfirmOpen(false);
      setMessage('');
      apiGet('/api/messages/history').then((d) =>
        setHistory((d.messages || []).filter((m: any) => m.className === params.classId))
      );
    } finally {
      setSending(false);
    }
  }

  if (!classDef) return <p>Unknown class</p>;

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-xl font-semibold">{classDef.labelGujarati} — વાલીઓને સામાન્ય સંદેશ</h1>

      <div className="card space-y-3">
        <textarea
          className="input min-h-[140px]"
          placeholder="અહીં સંદેશ લખો................"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <p className="text-xs text-gray-500 text-right">Character count: {message.length}</p>
        {counts && (
          <p className="text-sm text-gray-600">
            માન્ય વાલી નંબર: <span className="font-medium">{counts.uniqueValidMobiles}</span> / {counts.totalStudents}
          </p>
        )}
        <div className="grid sm:grid-cols-2 gap-3">
          <button
            className="btn-primary"
            disabled={!message.trim()}
            onClick={() => setConfirmOpen(true)}
          >
            Gateway દ્વારા મોકલો
          </button>
          <button
            className="btn bg-green-600 text-white hover:bg-green-700"
            disabled={!message.trim() || !(counts?.freeSmsRecipients?.length)}
            onClick={startFreeSmsQueue}
          >
            📱 Mobile SMS તૈયાર કરો
          </button>
        </div>
        {counts?.freeSmsRecipients?.length > 0 && (
          <div className="rounded-lg border border-green-200 bg-green-50 p-3 text-sm text-green-900">
            <p className="font-semibold">📱 Free Mobile SMS</p>
            <p className="mt-1">SMS Gateway વગર ફોનની SMS appમાં નંબર અને તમારો મેસેજ તૈયાર થશે. દરેક SMS માટે ફોનમાં <b>Send</b> દબાવવું પડશે.</p>
            {freeSmsIndex !== null && (
              <div className="mt-2 flex items-center justify-between gap-3">
                <span>SMS {Math.min(freeSmsIndex + 1, counts.freeSmsRecipients.length)} / {counts.freeSmsRecipients.length}</span>
                <button className="btn-secondary" onClick={openNextFreeSms}>➡️ Send કર્યા પછી આગળનો SMS</button>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="card">
        <h2 className="font-semibold mb-3">પાછલા સંદેશા</h2>
        {history.length === 0 ? (
          <p className="text-sm text-gray-500">હજુ સુધી કોઈ સંદેશ મોકલવામાં આવ્યો નથી.</p>
        ) : (
          <div className="space-y-2">
            {history.map((h) => (
              <div key={h.id} className="text-sm border-b border-gray-100 pb-2 last:border-0">
                <p className="line-clamp-2">{h.message}</p>
                <p className="text-gray-500 text-xs mt-1">
                  {new Date(h.createdAt).toLocaleString('en-IN')} · મોકલેલ {h.successful} · નિષ્ફળ {h.failed} · છોડેલ{' '}
                  {h.skipped}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      <ConfirmModal
        open={confirmOpen}
        title="સંદેશ મોકલવાની પુષ્ટિ"
        confirmLabel="મેસેજ મોકલો"
        onCancel={() => setConfirmOpen(false)}
        onConfirm={send}
        loading={sending}
      >
        <p>ધોરણ: {classDef.labelGujarati}</p>
        <p>કુલ વાલી નંબર: {counts?.uniqueValidMobiles ?? '—'}</p>
        <div className="bg-gray-50 rounded-lg p-3 text-xs whitespace-pre-wrap">{message}</div>
        <p className="font-medium pt-1">શું તમે આ સંદેશ {counts?.uniqueValidMobiles ?? 0} વાલીઓને મોકલવા માંગો છો?</p>
      </ConfirmModal>
    </div>
  );
}
