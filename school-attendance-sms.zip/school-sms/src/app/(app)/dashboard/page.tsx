'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { apiGet } from '@/lib/clientFetch';

type Card = {
  slug: string;
  labelGujarati: string;
  totalStudents: number;
  attendanceDate: string | null;
  present: number;
  absent: number;
  smsSent: number;
  smsFailed: number;
  attendanceUploaded: boolean;
};


const CLASS_COLORS = [
  { card: 'bg-blue-50 border-blue-200', title: 'text-blue-800', attendanceButton: 'bg-blue-600 hover:bg-blue-700', messageButton: 'bg-indigo-600 hover:bg-indigo-700' },
  { card: 'bg-green-50 border-green-200', title: 'text-green-800', attendanceButton: 'bg-green-600 hover:bg-green-700', messageButton: 'bg-emerald-600 hover:bg-emerald-700' },
  { card: 'bg-yellow-50 border-yellow-200', title: 'text-yellow-800', attendanceButton: 'bg-yellow-600 hover:bg-yellow-700', messageButton: 'bg-amber-600 hover:bg-amber-700' },
  { card: 'bg-orange-50 border-orange-200', title: 'text-orange-800', attendanceButton: 'bg-orange-600 hover:bg-orange-700', messageButton: 'bg-red-500 hover:bg-red-600' },
  { card: 'bg-purple-50 border-purple-200', title: 'text-purple-800', attendanceButton: 'bg-purple-600 hover:bg-purple-700', messageButton: 'bg-fuchsia-600 hover:bg-fuchsia-700' },
  { card: 'bg-pink-50 border-pink-200', title: 'text-pink-800', attendanceButton: 'bg-pink-600 hover:bg-pink-700', messageButton: 'bg-rose-600 hover:bg-rose-700' },
  { card: 'bg-sky-50 border-sky-200', title: 'text-sky-800', attendanceButton: 'bg-sky-600 hover:bg-sky-700', messageButton: 'bg-cyan-600 hover:bg-cyan-700' },
  { card: 'bg-red-50 border-red-200', title: 'text-red-800', attendanceButton: 'bg-red-600 hover:bg-red-700', messageButton: 'bg-rose-700 hover:bg-rose-800' },
];

export default function DashboardPage() {
  const [cards, setCards] = useState<Card[]>([]);
  const [totals, setTotals] = useState<any>(null);
  const [today, setToday] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet('/api/dashboard')
      .then((d) => {
        setCards(d.cards);
        setTotals(d.totals);
        setToday(d.today);
      })
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">ડેશબોર્ડ</h1>
        <p className="text-sm text-gray-500">તારીખ: {today}</p>
      </div>

      {loading ? (
        <p className="text-gray-500 text-sm">લોડ થઈ રહ્યું છે...</p>
      ) : (
        <>
          {totals && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <SummaryTile label="કુલ વિદ્યાર્થીઓ" value={totals.totalStudents} />
              <SummaryTile label="કુલ હાજર" value={totals.present} />
              <SummaryTile label="કુલ ગેરહાજર" value={totals.absent} />
              <SummaryTile label="SMS મોકલાયા" value={totals.smsSent} sub={totals.smsFailed ? `${totals.smsFailed} નિષ્ફળ` : undefined} />
            </div>
          )}

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {cards.map((c, index) => {
              const style = CLASS_COLORS[index % CLASS_COLORS.length];
              return (
                <div
                  key={c.slug}
                  className={`rounded-2xl border p-4 shadow-sm space-y-3 ${style.card}`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <h3 className={`font-bold ${style.title}`}>{c.labelGujarati}</h3>
                    {!c.attendanceUploaded && (
                      <span className="badge badge-pending">હાજરી બાકી</span>
                    )}
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-sm">
                    <div className="rounded-xl bg-white/75 px-2 py-2">
                      <p className="text-gray-500">કુલ</p>
                      <p className="font-bold text-gray-800">{c.totalStudents}</p>
                    </div>
                    <div className="rounded-xl bg-white/75 px-2 py-2">
                      <p className="text-gray-500">હાજર</p>
                      <p className="font-bold text-green-700">{c.present}</p>
                    </div>
                    <div className="rounded-xl bg-white/75 px-2 py-2">
                      <p className="text-gray-500">ગેરહાજર</p>
                      <p className="font-bold text-red-700">{c.absent}</p>
                    </div>
                  </div>

                  <div className="flex gap-2 flex-wrap">
                    <Link
                      href={`/attendance/${c.slug}`}
                      className={`btn text-sm flex-1 text-white shadow-sm ${style.attendanceButton}`}
                    >
                      હાજરી જુઓ
                    </Link>
                    <Link
                      href={`/messages/${c.slug}`}
                      className={`btn text-sm flex-1 text-white shadow-sm ${style.messageButton}`}
                    >
                      સામાન્ય સંદેશ
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

function SummaryTile({ label, value, sub }: { label: string; value: number; sub?: string }) {
  return (
    <div className="card">
      <p className="text-xs text-gray-500">{label}</p>
      <p className="text-2xl font-semibold">{value}</p>
      {sub && <p className="text-xs text-red-600 mt-0.5">{sub}</p>}
    </div>
  );
}
