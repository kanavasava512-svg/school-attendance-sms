'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { apiGet } from '@/lib/clientFetch';

type Card = {
  slug: string;
  labelGujarati: string;
  totalStudents: number;
  attendanceDate: string | null;
  present: number;
  absent: number;
  smsSent: number;
  smsFailed: number;
  attendanceUploaded: boolean;
};

export default function DashboardPage() {
  const [cards, setCards] = useState<Card[]>([]);
  const [totals, setTotals] = useState<any>(null);
  const [today, setToday] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet('/api/dashboard')
      .then((d) => {
        setCards(d.cards);
        setTotals(d.totals);
        setToday(d.today);
      })
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">ડેશબોર્ડ</h1>
        <p className="text-sm text-gray-500">તારીખ: {today}</p>
      </div>

      {loading ? (
        <p className="text-gray-500 text-sm">લોડ થઈ રહ્યું છે...</p>
      ) : (
        <>
          {totals && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <SummaryTile label="કુલ વિદ્યાર્થીઓ" value={totals.totalStudents} />
              <SummaryTile label="કુલ હાજર" value={totals.present} />
              <SummaryTile label="કુલ ગેરહાજર" value={totals.absent} />
              <SummaryTile label="SMS મોકલાયા" value={totals.smsSent} sub={totals.smsFailed ? `${totals.smsFailed} નિષ્ફળ` : undefined} />
            </div>
          )}

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {cards.map((c) => (
              <div key={c.slug} className="card space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{c.labelGujarati}</h3>
                  {!c.attendanceUploaded && (
                    <span className="badge badge-pending">હાજરી બાકી</span>
                  )}
                </div>
                <div className="grid grid-cols-3 gap-2 text-center text-sm">
                  <div>
                    <p className="text-gray-500">કુલ</p>
                    <p className="font-semibold">{c.totalStudents}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">હાજર</p>
                    <p className="font-semibold text-green-700">{c.present}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">ગેરહાજર</p>
                    <p className="font-semibold text-red-700">{c.absent}</p>
                  </div>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <Link href={`/attendance/${c.slug}`} className="btn-secondary text-sm flex-1">
                    હાજરી જુઓ
                  </Link>
                  <Link href={`/messages/${c.slug}`} className="btn-secondary text-sm flex-1">
                    સામાન્ય સંદેશ
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function SummaryTile({ label, value, sub }: { label: string; value: number; sub?: string }) {
  return (
    <div className="card">
      <p className="text-xs text-gray-500">{label}</p>
      <p className="text-2xl font-semibold">{value}</p>
      {sub && <p className="text-xs text-red-600 mt-0.5">{sub}</p>}
    </div>
  );
}
