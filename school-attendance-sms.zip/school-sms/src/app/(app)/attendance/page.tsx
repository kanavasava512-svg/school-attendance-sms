'use client';

import { useState } from 'react';
import Link from 'next/link';
import { CLASSES } from '@/lib/classes';

const CLASS_COLORS = [
  'bg-blue-50 border-blue-200 text-blue-900',
  'bg-green-50 border-green-200 text-green-900',
  'bg-yellow-50 border-yellow-200 text-yellow-900',
  'bg-orange-50 border-orange-200 text-orange-900',
  'bg-purple-50 border-purple-200 text-purple-900',
  'bg-pink-50 border-pink-200 text-pink-900',
  'bg-sky-50 border-sky-200 text-sky-900',
  'bg-red-50 border-red-200 text-red-900',
];

function localDateString() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

export default function AttendanceIndexPage() {
  const [selectedDate, setSelectedDate] = useState(localDateString());
  return (
    <div className="space-y-4">
      <div className="card flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <h1 className="text-xl font-semibold">હાજરી — ધોરણ પસંદ કરો</h1>
        <div className="flex items-center gap-2">
          <label className="text-sm font-medium text-gray-700">તારીખ</label>
          <input type="date" className="input w-auto" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
        </div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {CLASSES.map((c, index) => (
          <Link key={c.slug} href={`/attendance/${c.slug}?date=${selectedDate}`} className={`card hover:shadow-md transition border-2 ${CLASS_COLORS[index % CLASS_COLORS.length]}`}>
            <p className="font-semibold">{c.labelGujarati}</p>
            <p className="text-sm opacity-70">{c.labelEnglish}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
