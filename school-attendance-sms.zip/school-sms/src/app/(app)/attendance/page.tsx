import Link from 'next/link';
import { CLASSES } from '@/lib/classes';

export default function AttendanceIndexPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">હાજરી — ધોરણ પસંદ કરો</h1>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {CLASSES.map((c) => (
          <Link key={c.slug} href={`/attendance/${c.slug}`} className="card hover:shadow-md transition">
            <p className="font-semibold">{c.labelGujarati}</p>
            <p className="text-sm text-gray-500">{c.labelEnglish}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
