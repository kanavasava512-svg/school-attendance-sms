'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useParams } from 'next/navigation';
import { apiGet } from '@/lib/clientFetch';
import { toast } from '@/components/Toast';
import ConfirmModal from '@/components/ConfirmModal';
import StatusBadge from '@/components/StatusBadge';
import { getClass } from '@/lib/classes';

type Record_ = {
  id: string;
  studentId: string;
  childUid: string;
  studentName: string;
  studentNameGujarati: string | null;
  section: string | null;
  status: 'PRESENT' | 'ABSENT';
  mobileNumber: string | null;
  smsStatus: string | null;
};

export default function ClassAttendancePage() {
  const params = useParams<{ classId: string }>();
  const classDef = getClass(params.classId);

  const [role, setRole] = useState<'PRINCIPAL' | 'TEACHER' | null>(null);
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState<string>('');

  const fileRef = useRef<HTMLInputElement>(null);
  const [dateOverride, setDateOverride] = useState('');
  const [uploading, setUploading] = useState(false);
  const [duplicateInfo, setDuplicateInfo] = useState<{ existingCount: number } | null>(null);
  const [needDate, setNeedDate] = useState(false);

  const [previewOpen, setPreviewOpen] = useState(false);
  const [preview, setPreview] = useState<any>(null);
  const [freeSmsIndex, setFreeSmsIndex] = useState<number | null>(null);

  const load = useCallback(
    async (date?: string) => {
      setLoading(true);
      try {
        const q = date ? `?date=${date}` : '';
        const d = await apiGet(`/api/attendance/${params.classId}${q}`);
        setData(d);
        if (d.attendanceDate) setSelectedDate(d.attendanceDate);
      } finally {
        setLoading(false);
      }
    },
    [params.classId]
  );

  useEffect(() => {
    apiGet('/api/me').then((d) => setRole(d.session?.role ?? null));
    load();
  }, [load]);

  async function doUpload(confirmReplace = false) {
    const file = fileRef.current?.files?.[0];
    if (!file) {
      toast('PDF ફાઈલ પસંદ કરો.', 'error');
      return;
    }
    setUploading(true);
    setDuplicateInfo(null);
    setNeedDate(false);
    try {
      const fd = new FormData();
      fd.append('file', file);
      fd.append('classSlug', params.classId);
      if (dateOverride) fd.append('dateOverride', dateOverride);
      if (confirmReplace) fd.append('confirmReplace', 'true');

      const res = await fetch('/api/attendance/upload-pdf', { method: 'POST', body: fd });
      const result = await res.json();

      if (res.status === 409 && result.error === 'DUPLICATE_DATE') {
        setDuplicateInfo({ existingCount: result.existingCount });
        return;
      }
      if (res.status === 422 && result.error === 'DATE_REQUIRED') {
        setNeedDate(true);
        toast(result.detail, 'error');
        return;
      }
      if (!res.ok) {
        toast(result.detail || result.error || 'PDF પ્રોસેસ નિષ્ફળ', 'error');
        return;
      }

      toast(
        `PDF પ્રોસેસ થયું: ${result.absentCount} ગેરહાજર, ${result.presentCount} હાજર${
          result.unmatched ? `, ${result.unmatched} ચકાસણી બાકી` : ''
        }`,
        'success'
      );
      if (fileRef.current) fileRef.current.value = '';
      setDateOverride('');
      await load(result.attendanceDate);
    } finally {
      setUploading(false);
    }
  }

  async function openSmsPreview() {
    if (!selectedDate) return;
    const p = await apiGet(`/api/sms/attendance/preview?classSlug=${params.classId}&date=${selectedDate}`);
    setPreview(p);
    setPreviewOpen(true);
  }

  function openFreeSmsAt(index: number) {
    const recipients = preview?.freeSmsRecipients || [];
    const recipient = recipients[index];
    if (!recipient) return;

    setFreeSmsIndex(index);
    // Android/browser SMS apps support the sms/smsto URI and sms_body to
    // open a pre-filled compose screen. The user must still press Send.
    window.location.href = `sms:${recipient.mobile}?body=${encodeURIComponent(recipient.message)}`;
  }

  function startFreeSmsQueue() {
    const recipients = preview?.freeSmsRecipients || [];
    if (!recipients.length) {
      toast('મોકલવા માટે માન્ય મોબાઇલ નંબર મળ્યો નથી.', 'error');
      return;
    }
    openFreeSmsAt(0);
  }

  function openNextFreeSms() {
    const recipients = preview?.freeSmsRecipients || [];
    if (freeSmsIndex === null) {
      openFreeSmsAt(0);
      return;
    }
    const next = freeSmsIndex + 1;
    if (next >= recipients.length) {
      toast('બધા SMS તૈયાર થઈ ગયા. દરેક SMSમાં Send દબાવવાનું રહેશે.', 'success');
      return;
    }
    openFreeSmsAt(next);
  }

  async function resolveManual(rowId: string, studentId: string | null, skip: boolean) {
    const res = await fetch('/api/attendance/manual-match', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ unmatchedRowId: rowId, studentId, skip }),
    });
    if (res.ok) {
      toast('અપડેટ થયું', 'success');
      await load(selectedDate);
    }
  }

  if (!classDef) return <p>Unknown class</p>;

  const isPrincipal = role === 'PRINCIPAL';

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">{classDef.labelGujarati}</h1>
        {data?.attendanceDate && <p className="text-sm text-gray-500">તારીખ: {data.attendanceDate}</p>}
      </div>

      {isPrincipal && (
        <div className="card space-y-3">
          <h2 className="font-semibold text-sm">PDF અપલોડ</h2>
          <input ref={fileRef} type="file" accept=".pdf" className="input" />
          {needDate && (
            <div>
              <label className="block text-sm text-gray-600 mb-1">તારીખ પસંદ કરો (PDF માંથી શોધાઈ નથી)</label>
              <input
                type="date"
                className="input"
                value={dateOverride}
                onChange={(e) => setDateOverride(e.target.value)}
              />
            </div>
          )}
          <button className="btn-primary w-full" disabled={uploading} onClick={() => doUpload(false)}>
            {uploading ? 'પ્રોસેસ થઈ રહ્યું છે...' : 'PDF અપલોડ કરો'}
          </button>
          <a href="/help/pdf-format" className="text-sm text-brand-600 block text-center">
            PDF ફોર્મેટ જુઓ
          </a>
        </div>
      )}

      {loading ? (
        <p className="text-sm text-gray-500">લોડ થઈ રહ્યું છે...</p>
      ) : !data?.attendanceDate ? (
        <p className="text-sm text-gray-500 card">આ ધોરણની આજની હાજરી અપલોડ કરવામાં આવી નથી.</p>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <MiniStat label="કુલ વિદ્યાર્થીઓ" value={data.totalStudents} />
            <MiniStat label="હાજર" value={data.present} good />
            <MiniStat label="ગેરહાજર" value={data.absent} bad />
            <MiniStat
              label="SMS મોકલવા યોગ્ય"
              value={data.records.filter((r: Record_) => r.status === 'ABSENT' && r.mobileNumber && r.smsStatus == null).length}
            />
          </div>

          {isPrincipal && data.absent > 0 && (
            <button className="btn-primary w-full sm:w-auto" onClick={openSmsPreview}>
              ગેરહાજર વાલીઓને SMS મોકલો
            </button>
          )}

          {data.unmatched?.length > 0 && (
            <div className="card border-amber-300">
              <h2 className="font-semibold text-amber-700 mb-2">Manual Verification Required</h2>
              <div className="space-y-3">
                {data.unmatched.map((u: any) => (
                  <UnmatchedRow key={u.id} row={u} isPrincipal={isPrincipal} onResolve={resolveManual} />
                ))}
              </div>
            </div>
          )}

          <div className="card overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-500 border-b border-gray-100">
                  <th className="py-2 pr-3">ક્રમ</th>
                  <th className="py-2 pr-3">Child UID</th>
                  <th className="py-2 pr-3">વિદ્યાર્થીનું નામ</th>
                  <th className="py-2 pr-3">ગુજરાતી નામ</th>
                  <th className="py-2 pr-3">Status</th>
                  <th className="py-2 pr-3">Mobile</th>
                  <th className="py-2 pr-3">SMS Status</th>
                </tr>
              </thead>
              <tbody>
                {data.records.map((r: Record_, i: number) => (
                  <tr key={r.id} className="border-b border-gray-50 last:border-0">
                    <td className="py-2 pr-3">{i + 1}</td>
                    <td className="py-2 pr-3 font-mono text-xs">{r.childUid}</td>
                    <td className="py-2 pr-3">{r.studentName}</td>
                    <td className="py-2 pr-3">{r.studentNameGujarati || '—'}</td>
                    <td className="py-2 pr-3">
                      <StatusBadge status={r.status} />
                    </td>
                    <td className="py-2 pr-3">{r.mobileNumber || <span className="text-red-600 text-xs">ખૂટે છે</span>}</td>
                    <td className="py-2 pr-3">
                      <StatusBadge status={r.smsStatus} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      <ConfirmModal
        open={duplicateInfo !== null}
        title="આ તારીખની હાજરી પહેલેથી અપલોડ થયેલી છે."
        confirmLabel="Replace Attendance"
        onCancel={() => setDuplicateInfo(null)}
        onConfirm={() => {
          setDuplicateInfo(null);
          doUpload(true);
        }}
        danger
      >
        <p>{duplicateInfo?.existingCount} રેકોર્ડ પહેલેથી અસ્તિત્વમાં છે. શું તમે બદલવા માંગો છો?</p>
      </ConfirmModal>

      <ConfirmModal
        open={previewOpen}
        title="SMS મોકલવાની પુષ્ટિ"
        confirmLabel={
          preview
            ? freeSmsIndex === null
              ? `📱 ${preview.uniqueRecipients || preview.eligible} SMS તૈયાર કરો`
              : freeSmsIndex + 1 < (preview.freeSmsRecipients?.length || 0)
                ? '➡️ આગળનો SMS તૈયાર કરો'
                : '✅ પૂર્ણ કરો'
            : 'SMS તૈયાર કરો'
        }
        onCancel={() => {
          setPreviewOpen(false);
          setFreeSmsIndex(null);
        }}
        onConfirm={freeSmsIndex === null ? startFreeSmsQueue : openNextFreeSms}
      >
        {preview && (
          <div className="space-y-2">
            <Row label="ધોરણ" value={preview.classLabel} />
            <Row label="તારીખ" value={preview.dateLabel} />
            <Row label="ગેરહાજર વિદ્યાર્થીઓ" value={preview.totalAbsent} />
            <Row label="માન્ય મોબાઈલ નંબર (SMS મોકલવા યોગ્ય)" value={preview.eligible} />
            <Row label="Missing Mobile" value={preview.missingMobile} />
            <Row label="Already Sent" value={preview.alreadySent} />
            <p className="pt-2 font-medium">શું તમે {preview.eligible} વાલીઓને SMS મોકલવા માંગો છો?</p>

            <div className="rounded-lg border border-green-200 bg-green-50 p-3 mt-3 space-y-2">
              <p className="font-semibold text-green-800">📱 ફ્રી SMS — ફોનમાંથી મોકલો</p>
              <p className="text-xs text-green-700">
                SMS Gateway વગર. નંબર Contactsમાં Save કરવાની જરૂર નથી. દરેક SMSમાં બાળકનું નામ આપમેળે આવશે.
                Android SMS app ખુલશે અને મેસેજ તૈયાર રહેશે; તમારે ત્યાં <b>Send</b> દબાવવું પડશે.
              </p>
              {preview.freeSmsRecipients?.length > 0 && (
                <div className="rounded-lg bg-white border border-green-100 p-3 space-y-2">
                  <div className="text-sm font-semibold text-green-800">
                    {freeSmsIndex === null
                      ? `કુલ ${preview.freeSmsRecipients.length} SMS તૈયાર છે`
                      : `SMS ${Math.min(freeSmsIndex + 1, preview.freeSmsRecipients.length)} / ${preview.freeSmsRecipients.length}`}
                  </div>
                  {freeSmsIndex !== null && preview.freeSmsRecipients[freeSmsIndex] && (
                    <>
                      <div className="text-xs font-medium text-gray-700">
                        {preview.freeSmsRecipients[freeSmsIndex].students.join(', ')}
                      </div>
                      <div className="text-xs text-gray-500">
                        {preview.freeSmsRecipients[freeSmsIndex].mobile}
                      </div>
                      <button
                        type="button"
                        className="btn bg-blue-600 text-white hover:bg-blue-700 w-full"
                        onClick={openNextFreeSms}
                      >
                        {freeSmsIndex + 1 < preview.freeSmsRecipients.length
                          ? '➡️ Send કર્યા પછી આગળનો SMS તૈયાર કરો'
                          : '✅ છેલ્લો SMS — પૂર્ણ કરો'}
                      </button>
                    </>
                  )}
                  {freeSmsIndex === null && (
                    <p className="text-xs text-gray-600">
                      ઉપરનું “SMS તૈયાર કરો” દબાવ્યા પછી પ્રથમ SMS ખુલશે. Send કર્યા પછી અહીં પાછા આવીને આગળનો SMS તૈયાર કરો.
                    </p>
                  )}
                </div>
              )}
            </div>

            {preview.previewSamples?.[0] && (
              <div className="bg-gray-50 rounded-lg p-3 text-xs mt-2 whitespace-pre-wrap">
                <div className="font-medium mb-1">SMS Preview:</div>
                {preview.previewSamples[0].message}
              </div>
            )}
          </div>
        )}
      </ConfirmModal>
    </div>
  );
}

function Row({ label, value }: { label: string; value: any }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-gray-500">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

function MiniStat({ label, value, good, bad }: { label: string; value: number; good?: boolean; bad?: boolean }) {
  return (
    <div className="card">
      <p className="text-xs text-gray-500">{label}</p>
      <p className={`text-xl font-semibold ${good ? 'text-green-700' : bad ? 'text-red-700' : ''}`}>{value}</p>
    </div>
  );
}

function UnmatchedRow({
  row,
  isPrincipal,
  onResolve,
}: {
  row: any;
  isPrincipal: boolean;
  onResolve: (rowId: string, studentId: string | null, skip: boolean) => void;
}) {
  const [students, setStudents] = useState<any[]>([]);
  const [selected, setSelected] = useState('');

  useEffect(() => {
    apiGet(`/api/students?q=${encodeURIComponent(row.rawName)}&className=${row.className}`).then((d) =>
      setStudents(d.students || [])
    );
  }, [row]);

  return (
    <div className="border border-amber-200 rounded-lg p-3 text-sm space-y-2">
      <p>
        PDF Student: <span className="font-medium">{row.rawName}</span> ({row.rawChildUid || 'no UID'}) — {row.rawStatus}
      </p>
      {isPrincipal && (
        <div className="flex flex-wrap gap-2 items-center">
          <select className="input flex-1 min-w-[10rem]" value={selected} onChange={(e) => setSelected(e.target.value)}>
            <option value="">-- Select Student --</option>
            {students.map((s) => (
              <option key={s.id} value={s.id}>
                {s.studentName} ({s.childUid})
              </option>
            ))}
          </select>
          <button
            className="btn-secondary text-sm"
            disabled={!selected}
            onClick={() => onResolve(row.id, selected, false)}
          >
            Select Student
          </button>
          <button className="btn-secondary text-sm" onClick={() => onResolve(row.id, null, true)}>
            Skip
          </button>
        </div>
      )}
    </div>
  );
}
